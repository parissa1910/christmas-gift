export interface PhotoItem {
  id: string;
  url: string;
  caption: string;
  date?: string;
  location?: string;
}

export interface GiftStoryConfig {
  recipientName: string;
  senderName: string;
  cottageQuestion: string;
  cottageButtonText: string;
  photos: PhotoItem[];
  fireplaceQuote: string;
  fireplaceSubtext: string;
  letterEnvelopeTitle: string;
  letterGreeting: string;
  letterBody: string;
  letterSignoff: string;
  loveYouHeadline: string;
  loveYouSubtext: string;
  reasonsWhy: string[];
}

export type SceneId = 'cottage' | 'mantle' | 'fireplace' | 'letter' | 'loveyou';
