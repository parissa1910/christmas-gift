import React, { useState } from 'react';
import { Volume2, VolumeX, Music, Settings, Github } from 'lucide-react';
import { SceneId } from '../types';
import { audioEngine } from '../utils/audioEngine';

interface TopNavProps {
  currentScene: SceneId;
  onSelectScene: (scene: SceneId) => void;
  onOpenEditModal: () => void;
  onOpenGithubModal: () => void;
  isCustomizing: boolean;
  onToggleCustomizing: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentScene,
  onSelectScene,
  onOpenEditModal,
  onOpenGithubModal,
}) => {
  const [isMusicPlaying, setIsMusicPlaying] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  const handleToggleMusic = () => {
    const active = audioEngine.toggleMusic();
    setIsMusicPlaying(active);
  };

  const handleToggleMute = () => {
    const muted = audioEngine.toggleMute();
    setIsMuted(muted);
  };

  const scenes: { id: SceneId; label: string }[] = [
    { id: 'cottage', label: 'Cottage' },
    { id: 'mantle', label: 'Photos' },
    { id: 'fireplace', label: 'Fire' },
    { id: 'letter', label: 'Letter' },
    { id: 'loveyou', label: 'I Love You' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-[#fffdf9]/90 backdrop-blur-md border-b border-[#e9dfd1] px-4 md:px-7 py-2 transition-colors shadow-xs">
      <div className="max-w-5xl mx-auto flex items-center justify-between gap-4">
        {/* Brand: Merry Christmas */}
        <button
          onClick={() => onSelectScene('cottage')}
          className="text-xl font-script text-[#852526] hover:text-[#a13334] transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer text-left"
        >
          <span className="text-base">🎄</span>
          <span className="font-bold">Merry Christmas</span>
        </button>

        {/* Clean, handwritten navigation links */}
        <nav className="hidden md:flex items-center gap-5 text-sm font-hand text-[#6b584c]">
          {scenes.map((s) => {
            const isActive = currentScene === s.id;
            return (
              <button
                key={s.id}
                onClick={() => onSelectScene(s.id)}
                className={`transition-colors whitespace-nowrap cursor-pointer pb-0.5 ${
                  isActive
                    ? 'text-[#9e2a2b] font-bold border-b-2 border-[#9e2a2b]'
                    : 'hover:text-[#3e322b] text-[#7d695b]'
                }`}
              >
                {s.label}
              </button>
            );
          })}
        </nav>

        {/* Controls: light, natural paper buttons, slightly reduced size */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={handleToggleMusic}
            title={isMusicPlaying ? 'Pause Music' : 'Play Christmas Music'}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-hand transition-all cursor-pointer ${
              isMusicPlaying
                ? 'bg-[#eef5ed] text-[#2c5e3b] border border-[#bed8c2] shadow-xs'
                : 'paper-btn text-[#5c4a3e]'
            }`}
          >
            <Music className={`w-3 h-3 ${isMusicPlaying ? 'text-[#2c5e3b]' : ''}`} />
            <span>{isMusicPlaying ? 'Music on' : 'Music'}</span>
          </button>

          <button
            onClick={handleToggleMute}
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
            className="p-1.5 rounded-full paper-btn text-[#6b584c] cursor-pointer"
            aria-label="Toggle Mute"
          >
            {isMuted ? <VolumeX className="w-3 h-3 text-[#9e2a2b]" /> : <Volume2 className="w-3 h-3" />}
          </button>

          <button
            onClick={onOpenEditModal}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-hand text-[#544135] paper-btn rounded-full cursor-pointer"
            title="Edit photos and letter"
          >
            <Settings className="w-3 h-3 text-[#8f745f]" />
            <span className="hidden sm:inline">Edit</span>
          </button>

          <button
            onClick={onOpenGithubModal}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-hand text-[#544135] paper-btn rounded-full cursor-pointer"
            title="How to deploy to GitHub"
          >
            <Github className="w-3 h-3 text-[#735d4d]" />
            <span className="hidden md:inline">Deploy</span>
          </button>
        </div>
      </div>
    </header>
  );
};
