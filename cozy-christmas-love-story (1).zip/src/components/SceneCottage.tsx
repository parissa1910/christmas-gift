import React, { useState } from 'react';
import { DoorOpen } from 'lucide-react';
import { COTTAGE_IMAGE } from '../utils/defaultData';
import { audioEngine } from '../utils/audioEngine';

interface SceneCottageProps {
  questionText: string;
  buttonText: string;
  recipientName: string;
  onEnterCottage: () => void;
  onOpenSnowballGame: () => void;
}

export const SceneCottage: React.FC<SceneCottageProps> = ({
  questionText,
  buttonText,
  recipientName,
  onEnterCottage,
  onOpenSnowballGame,
}) => {
  const [isApproaching, setIsApproaching] = useState<boolean>(false);
  const [doorOpening, setDoorOpening] = useState<boolean>(false);

  const handleOpenDoor = () => {
    setDoorOpening(true);
    audioEngine.playDoorOpenSound();
    setTimeout(() => {
      onEnterCottage();
    }, 1000);
  };

  const handleApproach = () => {
    setIsApproaching(true);
    audioEngine.playSnowflakeSparkle();
  };

  const displayName = recipientName && recipientName.trim() ? recipientName.trim() : 'Nikki';

  return (
    <div className="relative w-full min-h-[calc(100vh-56px)] flex items-center justify-center overflow-hidden py-8 px-4 sm:px-6">
      {/* Background Storybook Cottage */}
      <div
        className={`absolute inset-0 bg-cover bg-center transition-transform duration-1000 ease-out ${
          isApproaching ? 'scale-115 translate-y-2' : 'scale-100'
        }`}
        style={{
          backgroundImage: `url(${COTTAGE_IMAGE})`,
        }}
      >
        {/* Soft, light watercolor overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#f5ede3]/70 via-transparent to-[#e8edf2]/30" />
      </div>

      {/* Gentle Door Opening Warmth */}
      <div
        className={`fixed inset-0 z-40 bg-[#fffbf2] transition-opacity duration-1000 pointer-events-none ${
          doorOpening ? 'opacity-95' : 'opacity-0'
        }`}
      />

      {/* Foreground Natural Content */}
      <div className="relative z-30 max-w-md w-full text-center flex flex-col items-center">
        {/* Title: Merry Christmas Nikki! */}
        <h1 className="text-3xl sm:text-5xl font-script font-bold text-[#3d2f26] drop-shadow-xs tracking-wide mb-1.5">
          Merry Christmas {displayName}!
        </h1>

        {/* Natural, light-colored paper box (slightly reduced size) */}
        {!isApproaching ? (
          <div className="mt-4 paper-box-warm p-4 sm:p-5 max-w-sm w-full flex flex-col items-center gap-3">
            <p className="text-lg sm:text-xl font-hand text-[#5a483c] leading-relaxed">
              Snow is falling gently outside the cottage...
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-2.5 w-full justify-center">
              <button
                onClick={handleApproach}
                className="w-full sm:w-auto px-5 py-2 rounded-full paper-btn-festive font-hand text-base cursor-pointer"
              >
                Walk to the door →
              </button>
              <button
                onClick={onOpenSnowballGame}
                className="w-full sm:w-auto px-4 py-2 rounded-full paper-btn font-hand text-sm cursor-pointer"
              >
                ❄️ Play in the snow
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-3 paper-box-warm p-4 sm:p-6 max-w-sm w-full flex flex-col items-center animate-fade-in">
            {/* Hand-drawn wreath symbol */}
            <div className="w-12 h-12 rounded-full bg-[#f4ebe1] border border-[#dfcdbb] flex items-center justify-center text-xl shadow-xs mb-2.5 animate-sway">
              🌿
            </div>

            <h2 className="text-xl sm:text-2xl font-script font-bold text-[#453429] mb-3">
              {questionText || 'Would you like to go inside?'}
            </h2>

            <div className="flex flex-col w-full gap-2.5">
              <button
                onClick={handleOpenDoor}
                disabled={doorOpening}
                className="w-full py-2.5 px-5 rounded-full paper-btn-festive font-hand text-lg flex items-center justify-center gap-2 cursor-pointer"
              >
                <DoorOpen className="w-4 h-4" />
                <span>{doorOpening ? 'Opening the door...' : buttonText || 'open the door'}</span>
              </button>

              <div className="flex items-center justify-center gap-3 mt-1">
                <button
                  onClick={onOpenSnowballGame}
                  className="text-sm font-hand text-[#852526] hover:underline cursor-pointer"
                >
                  quick snowball toss first
                </button>
                <span className="text-[#c7b7a6]">·</span>
                <button
                  onClick={() => setIsApproaching(false)}
                  className="text-sm font-hand text-[#756456] hover:text-[#3d2f26] cursor-pointer"
                >
                  go outside
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
