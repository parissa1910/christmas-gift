import React, { useState } from 'react';
import { X, Github, Copy, Check, Globe } from 'lucide-react';

interface GitHubDeployModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GitHubDeployModal: React.FC<GitHubDeployModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [tab, setTab] = useState<'vercel' | 'github'>('vercel');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const vercelSteps = [
    {
      title: 'Method 1: Connect with GitHub (Easiest & Free)',
      detail: 'If you pushed your repository to GitHub, go to vercel.com and sign up/log in with GitHub. Click "Add New Project", select your repository, and click "Deploy". Vercel auto-detects Vite and publishes your site in ~30 seconds with a free link (e.g. merry-christmas-nikki.vercel.app)!',
      command: '',
    },
    {
      title: 'Method 2: One-Command Deploy via Vercel CLI',
      detail: 'Open terminal/command prompt in this project folder and run:',
      command: `npm install -g vercel\nvercel`,
    },
    {
      title: 'Production Publish',
      detail: 'When you are ready to publish the final live version:',
      command: `vercel --prod`,
    },
  ];

  const githubSteps = [
    {
      title: '1. Create a Repository on GitHub',
      detail: 'Go to github.com/new and create a new repository (e.g. "christmas-gift"). Leave "Initialize with README" unchecked.',
      command: '',
    },
    {
      title: '2. Push your project code',
      detail: 'In terminal or command prompt in this project folder, run:',
      command: `git init\ngit add .\ngit commit -m "Merry Christmas Gift"\ngit branch -M main\ngit remote add origin https://github.com/<YOUR-USERNAME>/<YOUR-REPO-NAME>.git\ngit push -u origin main`,
    },
    {
      title: '3. Enable GitHub Pages',
      detail: 'In your repository on GitHub, open Settings → Pages. Under "Build and deployment", choose GitHub Actions or publish the dist folder.',
      command: `npm run build\nnpx gh-pages -d dist`,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#3d2f26]/30 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-xl paper-box-warm overflow-hidden flex flex-col max-h-[88vh] shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-[#ebd9c2] bg-[#fffdfa]">
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-[#852526]" />
            <h3 className="text-2xl font-script font-bold text-[#423226]">
              Deploy & Publish Your Gift
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#8f7d6f] hover:text-[#3e322b] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-2 px-6 py-2 border-b border-[#ebd9c2] bg-[#fbf7f0] font-hand text-base">
          <button
            onClick={() => setTab('vercel')}
            className={`px-4 py-1 rounded-full transition-colors cursor-pointer ${
              tab === 'vercel'
                ? 'paper-btn-festive shadow-xs'
                : 'text-[#6b584a] hover:bg-[#ede3d5]'
            }`}
          >
            ▲ Deploy to Vercel (Recommended)
          </button>
          <button
            onClick={() => setTab('github')}
            className={`px-4 py-1 rounded-full transition-colors cursor-pointer ${
              tab === 'github'
                ? 'paper-btn-festive shadow-xs'
                : 'text-[#6b584a] hover:bg-[#ede3d5]'
            }`}
          >
            GitHub Pages
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-left font-hand text-base text-[#4a392e]">
          {tab === 'vercel' ? (
            <>
              <p className="text-lg leading-relaxed">
                Vercel is the fastest and easiest way to host this website. It provides free automatic HTTPS, blazing-fast global speeds, and a free <code className="bg-[#eee4d4] px-1.5 py-0.5 rounded font-mono text-xs">.vercel.app</code> domain you can text to him!
              </p>

              <div className="space-y-4">
                {vercelSteps.map((step, idx) => (
                  <div key={idx} className="space-y-1.5">
                    <h4 className="font-bold text-lg text-[#852526]">{step.title}</h4>
                    <p className="text-sm text-[#6b584a]">{step.detail}</p>
                    {step.command && (
                      <div className="relative">
                        <pre className="p-3 bg-[#fdfbf7] border border-[#ebd9c2] rounded-xl text-[#3b4c3e] font-mono text-xs overflow-x-auto whitespace-pre">
                          {step.command}
                        </pre>
                        <button
                          onClick={() => copyToClipboard(step.command, idx)}
                          className="absolute top-2 right-2 px-2.5 py-1 bg-[#fffdfa] hover:bg-[#faf5ec] text-[#544135] rounded-lg text-xs flex items-center gap-1 border border-[#ebd9c2] cursor-pointer"
                        >
                          {copiedIndex === idx ? (
                            <>
                              <Check className="w-3 h-3 text-[#2c5e3b]" />
                              <span>Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>
          ) : (
            <>
              <p className="text-lg leading-relaxed">
                We already configured <code className="bg-[#eee4d4] px-1.5 py-0.5 rounded font-mono text-xs">base: './'</code> in <code className="bg-[#eee4d4] px-1.5 py-0.5 rounded font-mono text-xs">vite.config.ts</code> so the website works right out of the box on GitHub Pages!
              </p>

              <div className="space-y-4">
                {githubSteps.map((step, idx) => (
                  <div key={idx} className="space-y-1.5">
                    <h4 className="font-bold text-lg text-[#852526]">{step.title}</h4>
                    <p className="text-sm text-[#6b584a]">{step.detail}</p>
                    {step.command && (
                      <div className="relative">
                        <pre className="p-3 bg-[#fdfbf7] border border-[#ebd9c2] rounded-xl text-[#3b4c3e] font-mono text-xs overflow-x-auto whitespace-pre">
                          {step.command}
                        </pre>
                        <button
                          onClick={() => copyToClipboard(step.command, idx)}
                          className="absolute top-2 right-2 px-2.5 py-1 bg-[#fffdfa] hover:bg-[#faf5ec] text-[#544135] rounded-lg text-xs flex items-center gap-1 border border-[#ebd9c2] cursor-pointer"
                        >
                          {copiedIndex === idx ? (
                            <>
                              <Check className="w-3 h-3 text-[#2c5e3b]" />
                              <span>Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-3 bg-[#fffdfa] border-t border-[#ebd9c2]">
          <button
            onClick={onClose}
            className="px-5 py-1.5 font-hand text-lg paper-btn-festive rounded-full cursor-pointer"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
