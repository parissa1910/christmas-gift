import React, { useEffect, useRef } from 'react';
import { audioEngine } from '../utils/audioEngine';

interface Snowflake {
  x: number;
  y: number;
  radius: number;
  speed: number;
  wind: number;
  windOffset: number;
  opacity: number;
}

interface SparkleParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  alpha: number;
  decay: number;
  size: number;
}

export const SnowCanvas: React.FC<{ interactive?: boolean }> = ({ interactive = true }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const sparklesRef = useRef<SparkleParticle[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Generate snowflakes
    const count = Math.min(100, Math.floor((width * height) / 12000));
    const snowflakes: Snowflake[] = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: Math.random() * 2.8 + 0.8,
      speed: Math.random() * 1.2 + 0.6,
      wind: Math.random() * 0.8 - 0.4,
      windOffset: Math.random() * Math.PI * 2,
      opacity: Math.random() * 0.6 + 0.35,
    }));

    let time = 0;

    const render = () => {
      time += 0.015;
      ctx.clearRect(0, 0, width, height);

      // Render & update snowflakes
      ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
      for (let i = 0; i < snowflakes.length; i++) {
        const flake = snowflakes[i];
        flake.y += flake.speed;
        flake.x += Math.sin(time + flake.windOffset) * 0.7 + flake.wind;

        // Wrap around
        if (flake.y > height) {
          flake.y = -5;
          flake.x = Math.random() * width;
        }
        if (flake.x > width) flake.x = 0;
        if (flake.x < 0) flake.x = width;

        ctx.beginPath();
        ctx.arc(flake.x, flake.y, flake.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${flake.opacity})`;
        ctx.fill();
      }

      // Render interactive sparkles
      const sparkles = sparklesRef.current;
      for (let i = sparkles.length - 1; i >= 0; i--) {
        const s = sparkles[i];
        s.x += s.vx;
        s.y += s.vy;
        s.alpha -= s.decay;

        if (s.alpha <= 0) {
          sparkles.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.fillStyle = `rgba(254, 240, 138, ${s.alpha})`;
        ctx.shadowBlur = 10;
        ctx.shadowColor = 'rgba(253, 224, 71, 0.8)';
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!interactive) return;
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    audioEngine.playSnowflakeSparkle();

    // Spawn 12 sparkling festive stars
    for (let i = 0; i < 14; i++) {
      const angle = (Math.PI * 2 * i) / 14 + (Math.random() * 0.4 - 0.2);
      const speed = Math.random() * 2.5 + 1.2;
      sparklesRef.current.push({
        x: clickX,
        y: clickY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        alpha: 1,
        decay: Math.random() * 0.025 + 0.02,
        size: Math.random() * 2.5 + 1.5,
      });
    }
  };

  return (
    <canvas
      ref={canvasRef}
      onClick={handleClick}
      className={`fixed inset-0 pointer-events-${interactive ? 'auto' : 'none'} z-20`}
      style={{ pointerEvents: interactive ? 'auto' : 'none' }}
      title={interactive ? 'Click anywhere for Christmas magic sparkles!' : undefined}
    />
  );
};
