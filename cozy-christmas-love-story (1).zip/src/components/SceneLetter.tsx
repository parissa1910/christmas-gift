import React, { useState } from 'react';
import { ArrowRight, Edit3, Check, RefreshCw } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';

interface SceneLetterProps {
  envelopeTitle: string;
  greeting: string;
  body: string;
  signoff: string;
  onUpdateLetter: (greeting: string, body: string, signoff: string) => void;
  onNextSlide: () => void;
}

export const SceneLetter: React.FC<SceneLetterProps> = ({
  envelopeTitle,
  greeting,
  body,
  signoff,
  onUpdateLetter,
  onNextSlide,
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [greetingDraft, setGreetingDraft] = useState<string>(greeting);
  const [bodyDraft, setBodyDraft] = useState<string>(body);
  const [signoffDraft, setSignoffDraft] = useState<string>(signoff);

  const handleOpenLetter = () => {
    setIsOpen(true);
    audioEngine.playLetterOpenSound();
  };

  const handleSave = () => {
    onUpdateLetter(greetingDraft, bodyDraft, signoffDraft);
    setIsEditing(false);
  };

  const handleStartEdit = () => {
    setGreetingDraft(greeting);
    setBodyDraft(body);
    setSignoffDraft(signoff);
    setIsEditing(true);
  };

  return (
    <div className="relative w-full min-h-[calc(100vh-56px)] flex flex-col items-center justify-between py-6 px-4 sm:px-6 bg-[#f7f3eb] overflow-hidden">
      {/* Soft warm watercolor wash background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#fdfbf7] via-[#f7f2e8] to-[#eee4d6] pointer-events-none" />

      <div className="relative z-20" />

      {/* Main Interactive Letter Stage */}
      <div className="relative z-20 w-full max-w-lg flex-1 flex flex-col items-center justify-center my-auto">
        {!isOpen ? (
          /* Sealed Envelope View */
          <div
            onClick={handleOpenLetter}
            className="group relative w-full max-w-sm aspect-[16/11] bg-gradient-to-br from-[#9c3031] to-[#802223] rounded-2xl shadow-md border border-[#701c1d] p-5 flex flex-col items-center justify-between cursor-pointer transition-transform duration-300 hover:scale-102"
          >
            {/* Subtle envelope lines */}
            <div className="absolute top-0 inset-x-0 h-1/2 border-b border-[#b54a4b]/30 pointer-events-none" />

            <div />

            {/* Handwritten Title on Envelope */}
            <div className="text-center my-auto z-10">
              <h2 className="text-3xl sm:text-5xl font-script font-bold text-[#fff7ed] drop-shadow-xs">
                {envelopeTitle || 'Merry Christmas'}
              </h2>
            </div>

            {/* Wax Seal */}
            <div className="relative flex flex-col items-center -mb-1.5 z-10">
              <div className="w-14 h-14 rounded-full bg-[#751b1c] border-2 border-[#d4af37] shadow-sm flex items-center justify-center group-hover:scale-106 transition-transform">
                <span className="text-xl text-[#fef3c7]">❄️</span>
              </div>
            </div>
          </div>
        ) : (
          /* Opened Letter on Warm Cream Stationery */
          <div className="relative w-full paper-box-warm p-5 sm:p-7 flex flex-col max-h-[70vh] overflow-y-auto animate-scale-up">
            {/* Top Toolbar */}
            <div className="flex items-center justify-between pb-2.5 border-b border-[#ebd9c2] mb-2.5">
              <span className="font-hand text-base text-[#852526]">Merry Christmas</span>
              <div className="flex items-center gap-1.5">
                {!isEditing ? (
                  <button
                    onClick={handleStartEdit}
                    className="flex items-center gap-1 px-2.5 py-0.5 text-xs font-hand text-[#5c493c] paper-btn rounded-full cursor-pointer"
                  >
                    <Edit3 className="w-3 h-3" />
                    <span>Edit message</span>
                  </button>
                ) : (
                  <button
                    onClick={handleSave}
                    className="flex items-center gap-1 px-3 py-0.5 text-xs font-hand paper-btn-festive rounded-full cursor-pointer"
                  >
                    <Check className="w-3 h-3" />
                    <span>Save</span>
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 text-[#8f7d6e] hover:text-[#3e322b] cursor-pointer"
                  title="Close envelope"
                >
                  <RefreshCw className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Letter Content in natural handwritten font */}
            {!isEditing ? (
              <div className="flex flex-col text-left space-y-3 font-script text-xl sm:text-2xl text-[#36271e] leading-relaxed">
                <h3 className="font-script font-bold text-2xl sm:text-3xl text-[#852526]">
                  {greeting}
                </h3>

                <div className="whitespace-pre-line">
                  {body}
                </div>

                <div className="pt-3 text-right">
                  <p className="text-xl sm:text-2xl text-[#852526] font-bold">
                    {signoff}
                  </p>
                </div>
              </div>
            ) : (
              /* Inline Editing Form with light paper style */
              <div className="flex flex-col gap-2.5 text-left">
                <input
                  type="text"
                  value={greetingDraft}
                  onChange={(e) => setGreetingDraft(e.target.value)}
                  className="w-full px-2.5 py-1 bg-[#faf5ed] border border-[#ebd9c2] rounded-lg text-xl font-script text-[#36271e] focus:outline-none"
                  placeholder="Greeting..."
                />

                <textarea
                  rows={8}
                  value={bodyDraft}
                  onChange={(e) => setBodyDraft(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#faf5ed] border border-[#ebd9c2] rounded-lg text-lg font-hand leading-relaxed text-[#36271e] focus:outline-none"
                  placeholder="Write your letter..."
                />

                <input
                  type="text"
                  value={signoffDraft}
                  onChange={(e) => setSignoffDraft(e.target.value)}
                  className="w-full px-2.5 py-1 bg-[#faf5ed] border border-[#ebd9c2] rounded-lg text-lg font-script text-[#852526] focus:outline-none"
                  placeholder="Signoff..."
                />

                <div className="flex justify-end gap-2 mt-1">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="px-3 py-0.5 font-hand text-sm text-[#735e4f]"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    className="px-4 py-0.5 font-hand text-base rounded-full paper-btn-festive cursor-pointer"
                  >
                    Save
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Button to Move to Last "I Love You" Slide */}
      <div className="relative z-20 flex flex-col items-center mt-3">
        <button
          onClick={onNextSlide}
          className="flex items-center gap-2 px-6 py-2.5 rounded-full paper-btn-festive font-hand text-lg cursor-pointer"
        >
          <span>One last surprise</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
