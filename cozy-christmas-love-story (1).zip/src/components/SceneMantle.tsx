import React, { useState } from 'react';
import { PhotoItem } from '../types';
import { ChevronLeft, ChevronRight, Upload, Edit3, ArrowDown } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';
import { compressImageFile } from '../utils/imageCompressor';

interface SceneMantleProps {
  photos: PhotoItem[];
  onUpdatePhoto: (updated: PhotoItem) => void;
  onOpenFireplace: () => void;
}

export const SceneMantle: React.FC<SceneMantleProps> = ({
  photos,
  onUpdatePhoto,
  onOpenFireplace,
}) => {
  const [zoomedIndex, setZoomedIndex] = useState<number | null>(0);
  const [isEditingCaption, setIsEditingCaption] = useState<boolean>(false);
  const [captionDraft, setCaptionDraft] = useState<string>('');
  const [locationDraft, setLocationDraft] = useState<string>('');

  const activePhoto = zoomedIndex !== null ? photos[zoomedIndex] : null;

  const handleSelectPhoto = (index: number) => {
    setZoomedIndex(index);
    setIsEditingCaption(false);
    audioEngine.playSnowflakeSparkle();
  };

  const handleNextPhoto = () => {
    if (zoomedIndex === null) return;
    const next = (zoomedIndex + 1) % photos.length;
    setZoomedIndex(next);
    setIsEditingCaption(false);
    audioEngine.playSnowflakeSparkle();
  };

  const handlePrevPhoto = () => {
    if (zoomedIndex === null) return;
    const prev = (zoomedIndex - 1 + photos.length) % photos.length;
    setZoomedIndex(prev);
    setIsEditingCaption(false);
    audioEngine.playSnowflakeSparkle();
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, photoId: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const compressedDataUrl = await compressImageFile(file);
      const existing = photos.find((p) => p.id === photoId);
      if (existing) {
        onUpdatePhoto({
          ...existing,
          url: compressedDataUrl,
        });
      }
    } catch {
      // Graceful fallback
    }
  };

  const handleSaveCaption = () => {
    if (!activePhoto) return;
    onUpdatePhoto({
      ...activePhoto,
      caption: captionDraft,
      location: locationDraft,
    });
    setIsEditingCaption(false);
  };

  const startEditing = () => {
    if (!activePhoto) return;
    setCaptionDraft(activePhoto.caption);
    setLocationDraft(activePhoto.location || '');
    setIsEditingCaption(true);
  };

  const hasLocationOrDate = Boolean(activePhoto?.location?.trim() || activePhoto?.date?.trim());

  return (
    <div className="relative w-full min-h-[calc(100vh-56px)] flex flex-col items-center justify-between py-5 px-4 sm:px-6 bg-[#f8f5ee] overflow-hidden">
      {/* Soft warm indoor watercolor background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#fbf8f2] via-[#f5ede0] to-[#ecdfce] pointer-events-none" />

      {/* Gentle holiday garland across top */}
      <div className="relative z-20 w-full max-w-3xl flex flex-col items-center mb-2">
        {/* Soft fairy lights */}
        <div className="w-full flex justify-around items-center py-1 opacity-75">
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className={`w-2 h-2 rounded-full shadow-xs ${
                i % 3 === 0
                  ? 'bg-[#f4bc59]'
                  : i % 3 === 1
                  ? 'bg-[#c54b4b]'
                  : 'bg-[#5f8f6d]'
              }`}
            />
          ))}
        </div>

        {/* Header Title */}
        <h2 className="text-2xl sm:text-3xl font-script font-bold text-[#423329] mt-1.5">
          Pictures on the mantle
        </h2>
      </div>

      {/* Mantle & Zoomed Photo Showcase */}
      <div className="relative z-20 w-full max-w-xl flex-1 flex flex-col items-center justify-center my-1.5">
        {zoomedIndex !== null && activePhoto ? (
          /* Zoomed-in Photo Card in natural light paper styling */
          <div className="relative flex flex-col items-center w-full paper-box-warm p-3.5 sm:p-5 shadow-md animate-scale-up">
            {/* Wooden Picture Frame */}
            <div className="relative w-full aspect-[4/3] rounded-lg overflow-hidden bg-[#eee6da] border-5 border-[#d9c5ab] shadow-inner">
              <img
                src={activePhoto.url}
                alt={activePhoto.caption}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />

              {/* Upload photo button */}
              <label className="absolute top-2.5 right-2.5 p-1.5 rounded-full bg-[#fffcf7]/90 hover:bg-[#fff] text-[#544135] border border-[#d6c5b2] shadow-xs cursor-pointer transition-transform hover:scale-105">
                <Upload className="w-3.5 h-3.5" />
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => handleFileUpload(e, activePhoto.id)}
                />
              </label>
            </div>

            {/* Handwritten Caption */}
            <div className="w-full mt-3 flex flex-col">
              {!isEditingCaption ? (
                <div className="flex items-start justify-between gap-3">
                  <div className="text-left flex-1">
                    <p className="text-xl sm:text-2xl font-hand text-[#382b22] leading-snug">
                      "{activePhoto.caption}"
                    </p>
                    {hasLocationOrDate && (
                      <p className="text-sm font-hand text-[#826e5f] mt-0.5">
                        {activePhoto.location} {activePhoto.date ? `· ${activePhoto.date}` : ''}
                      </p>
                    )}
                  </div>
                  <button
                    onClick={startEditing}
                    className="p-1 text-[#735c4c] hover:text-[#382b22] paper-btn rounded-md cursor-pointer shrink-0"
                    title="Edit caption"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="w-full flex flex-col gap-2 p-2.5 rounded-lg bg-[#fffefb] border border-[#d8c8b4]">
                  <input
                    type="text"
                    value={captionDraft}
                    onChange={(e) => setCaptionDraft(e.target.value)}
                    className="w-full px-2.5 py-1 bg-[#faf5ed] text-[#382b22] rounded-md border border-[#d8c8b4] font-hand text-lg focus:outline-none"
                    placeholder="Write a sweet memory..."
                  />
                  <input
                    type="text"
                    value={locationDraft}
                    onChange={(e) => setLocationDraft(e.target.value)}
                    className="w-full px-2.5 py-1 bg-[#faf5ed] text-[#6b584a] rounded-md border border-[#d8c8b4] font-hand text-sm focus:outline-none"
                    placeholder="Location or date (optional)"
                  />
                  <div className="flex justify-end gap-2 mt-1">
                    <button
                      onClick={() => setIsEditingCaption(false)}
                      className="px-3 py-0.5 font-hand text-sm text-[#7a6758] hover:text-[#382b22]"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveCaption}
                      className="px-3.5 py-0.5 font-hand text-sm rounded-full paper-btn-festive cursor-pointer"
                    >
                      Save
                    </button>
                  </div>
                </div>
              )}

              {/* Prev / Next photo controls */}
              <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-[#ebd9c2]">
                <button
                  onClick={handlePrevPhoto}
                  className="flex items-center gap-1 font-hand text-base text-[#5a483a] hover:text-[#852526] transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Previous</span>
                </button>

                <div className="flex gap-1.5">
                  {photos.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSelectPhoto(idx)}
                      className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                        idx === zoomedIndex ? 'bg-[#9e2a2b] scale-115' : 'bg-[#d8c8b7] hover:bg-[#b5a290]'
                      }`}
                    />
                  ))}
                </div>

                <button
                  onClick={handleNextPhoto}
                  className="flex items-center gap-1 font-hand text-base text-[#5a483a] hover:text-[#852526] transition-colors cursor-pointer"
                >
                  <span>Next</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Shelf Overview */
          <div className="w-full flex flex-col items-center">
            <div className="flex justify-center items-end gap-3 sm:gap-5 px-4 pb-2">
              {photos.map((photo, idx) => (
                <div
                  key={photo.id}
                  onClick={() => handleSelectPhoto(idx)}
                  className="cursor-pointer transition-transform duration-200 hover:-translate-y-1.5 flex flex-col items-center"
                >
                  <div className="w-28 sm:w-36 aspect-[4/3] rounded-lg overflow-hidden border-3 border-[#cfbc9f] bg-[#ebdcc8] shadow-xs">
                    <img
                      src={photo.url}
                      alt={photo.caption}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="font-hand text-sm text-[#5c493c] mt-1 truncate max-w-[110px]">
                    {photo.caption}
                  </span>
                </div>
              ))}
            </div>

            {/* Natural warm wooden mantle beam */}
            <div className="w-full max-w-xl h-4 bg-gradient-to-r from-[#b38e67] via-[#c9a67e] to-[#b38e67] rounded-sm shadow-xs border-t border-[#d8bc98]" />
          </div>
        )}
      </div>

      {/* Move to Fireplace Button */}
      <div className="relative z-20 flex flex-col items-center mt-2">
        <button
          onClick={onOpenFireplace}
          className="flex items-center gap-1.5 px-6 py-2 rounded-full paper-btn font-hand text-lg text-[#4a392e] hover:text-[#852526] cursor-pointer"
        >
          <span>Look at the fire below</span>
          <ArrowDown className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
