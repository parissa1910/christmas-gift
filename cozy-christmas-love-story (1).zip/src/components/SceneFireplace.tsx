import React, { useEffect, useState } from 'react';
import { ArrowRight, Edit3 } from 'lucide-react';
import { FIREPLACE_IMAGE } from '../utils/defaultData';
import { audioEngine } from '../utils/audioEngine';

interface SceneFireplaceProps {
  quote: string;
  subtext: string;
  onUpdateQuote: (quote: string, subtext: string) => void;
  onOpenLetter: () => void;
}

export const SceneFireplace: React.FC<SceneFireplaceProps> = ({
  quote,
  subtext,
  onUpdateQuote,
  onOpenLetter,
}) => {
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [quoteDraft, setQuoteDraft] = useState<string>(quote);
  const [subtextDraft, setSubtextDraft] = useState<string>(subtext);

  useEffect(() => {
    audioEngine.startFireCrackle();
    return () => {
      audioEngine.stopFireCrackle();
    };
  }, []);

  const handleSave = () => {
    onUpdateQuote(quoteDraft, subtextDraft);
    setIsEditing(false);
  };

  return (
    <div className="relative w-full min-h-[calc(100vh-56px)] flex flex-col items-center justify-between py-8 px-4 sm:px-6 overflow-hidden">
      {/* Zoomed-in Close-up Shot of the Burning Fire */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-transform duration-1000"
        style={{
          backgroundImage: `url(${FIREPLACE_IMAGE})`,
        }}
      >
        {/* Soft, warm golden vignette */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#2a1b12]/75 via-transparent to-[#1a120c]/60" />
      </div>

      {/* Floating Gentle Embers */}
      <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden">
        {Array.from({ length: 12 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-[#fbd38d] opacity-75 animate-float-slow"
            style={{
              width: `${Math.random() * 3 + 2}px`,
              height: `${Math.random() * 3 + 2}px`,
              bottom: `${Math.random() * 45 + 15}%`,
              left: `${Math.random() * 60 + 20}%`,
              animationDuration: `${Math.random() * 3 + 2}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-20" />

      {/* Centerpiece: The Quote in a natural, warm paper card */}
      <div className="relative z-20 max-w-lg w-full flex flex-col items-center text-center my-auto px-2">
        {!isEditing ? (
          <div className="bg-[#fffdfa]/90 backdrop-blur-md border border-[#ebd9c5] p-5 sm:p-7 rounded-2xl shadow-md relative group">
            {/* The Quote */}
            <h2 className="text-2xl sm:text-4xl font-script font-bold text-[#3e2c22] leading-tight">
              "{quote}"
            </h2>

            {subtext && (
              <p className="text-lg sm:text-xl font-hand text-[#6b5545] mt-2.5 leading-relaxed">
                {subtext}
              </p>
            )}

            {/* Subtle edit button */}
            <button
              onClick={() => {
                setQuoteDraft(quote);
                setSubtextDraft(subtext);
                setIsEditing(true);
              }}
              className="absolute top-2.5 right-2.5 p-1 text-[#917968] hover:text-[#3e2c22] opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
              title="Edit text"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <div className="bg-[#fffdfa] border border-[#ebd9c5] p-5 rounded-2xl shadow-md w-full flex flex-col gap-2.5 text-left">
            <textarea
              rows={2}
              value={quoteDraft}
              onChange={(e) => setQuoteDraft(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-[#faf5ed] text-[#3e2c22] rounded-lg border border-[#ebd9c5] text-xl font-script focus:outline-none"
              placeholder="Enter your quote..."
            />
            <textarea
              rows={2}
              value={subtextDraft}
              onChange={(e) => setSubtextDraft(e.target.value)}
              className="w-full px-2.5 py-1 bg-[#faf5ed] text-[#6b5545] rounded-lg border border-[#ebd9c5] text-base font-hand focus:outline-none"
              placeholder="Sweet memory..."
            />
            <div className="flex justify-end gap-2 mt-1">
              <button
                onClick={() => setIsEditing(false)}
                className="px-3 py-0.5 font-hand text-sm text-[#735e4f] hover:text-[#3e2c22]"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-0.5 font-hand text-base rounded-full paper-btn-festive cursor-pointer"
              >
                Save
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Natural Paper Button to Move to Letter */}
      <div className="relative z-20 flex flex-col items-center mt-3">
        <button
          onClick={onOpenLetter}
          className="flex items-center gap-2 px-6 py-2.5 rounded-full paper-btn-festive font-hand text-lg cursor-pointer"
        >
          <span>Open your Christmas letter</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
