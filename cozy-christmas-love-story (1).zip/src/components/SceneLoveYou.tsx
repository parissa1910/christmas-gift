import React, { useState } from 'react';
import { Heart, RotateCcw, Share2, Check } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';

interface SceneLoveYouProps {
  recipientName: string;
  senderName: string;
  headline: string;
  subtext: string;
  onRestart: () => void;
  onOpenEditModal: () => void;
  onOpenGithubModal: () => void;
}

interface HeartParticle {
  id: number;
  x: number;
  y: number;
  size: number;
  speedY: number;
  rotation: number;
}

export const SceneLoveYou: React.FC<SceneLoveYouProps> = ({
  senderName,
  headline,
  onRestart,
}) => {
  const [floatingHearts, setFloatingHearts] = useState<HeartParticle[]>([]);
  const [copied, setCopied] = useState<boolean>(false);

  const spawnHearts = () => {
    audioEngine.playHeartSound();
    const newHearts: HeartParticle[] = Array.from({ length: 14 }, () => ({
      id: Date.now() + Math.random(),
      x: Math.random() * window.innerWidth * 0.8 + window.innerWidth * 0.1,
      y: window.innerHeight - 60,
      size: Math.random() * 16 + 12,
      speedY: Math.random() * 2.5 + 1.8,
      rotation: Math.random() * 30 - 15,
    }));
    setFloatingHearts((prev) => [...prev, ...newHearts]);

    setTimeout(() => {
      setFloatingHearts((prev) => prev.slice(newHearts.length));
    }, 2600);
  };

  const handleCopyLink = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="relative w-full min-h-[calc(100vh-56px)] flex flex-col items-center justify-between py-8 px-4 sm:px-6 bg-[#faf6f0] overflow-hidden">
      {/* Soft watercolor rose and ivory wash */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#fdfbf7] via-[#faf4ed] to-[#f4ebe1] pointer-events-none" />

      {/* Floating Gentle Hearts */}
      {floatingHearts.map((h) => (
        <div
          key={h.id}
          className="fixed pointer-events-none z-50 text-[#c74343] transition-transform duration-1000 animate-fade-out"
          style={{
            left: h.x,
            bottom: h.y,
            fontSize: `${h.size}px`,
            transform: `translateY(-${h.speedY * 50}px) rotate(${h.rotation}deg)`,
          }}
        >
          ❤️
        </div>
      ))}

      <div className="relative z-20" />

      {/* Centerpiece: Clean, Sweet, Hand-drawn Romantic Card */}
      <div className="relative z-20 max-w-md w-full text-center flex flex-col items-center my-auto px-4">
        {/* Soft hand-drawn heart */}
        <div className="relative mb-2.5 flex items-center justify-center">
          <div className="w-13 h-13 rounded-full bg-[#fcedec] border-2 border-[#ebd1d1] shadow-xs flex items-center justify-center text-2xl animate-bounce">
            ❤️
          </div>
          <span className="absolute -top-1.5 -right-1.5 text-lg animate-sway">🌿</span>
        </div>

        {/* Headline */}
        <h1 className="text-3xl sm:text-5xl font-script font-bold text-[#3d2b21] tracking-wide leading-tight">
          {headline || 'I Love You'}
        </h1>

        {/* Handwritten signature */}
        <div className="mt-3 text-[#852526] font-script text-2xl sm:text-3xl font-bold">
          — {senderName || 'Forever Yours'} ♡
        </div>

        {/* Sweet Heart Burst Button */}
        <div className="mt-5">
          <button
            onClick={spawnHearts}
            className="flex items-center gap-1.5 px-5 py-2 rounded-full paper-btn font-hand text-base text-[#852526] hover:text-[#a83234] cursor-pointer"
          >
            <Heart className="w-3.5 h-3.5 fill-[#c74343] text-[#c74343]" />
            <span>Send hearts</span>
          </button>
        </div>
      </div>

      {/* Clean Footer Controls */}
      <div className="relative z-20 w-full max-w-sm flex items-center justify-between gap-3 pt-4 border-t border-[#ebd9c2] mt-3">
        <button
          onClick={onRestart}
          className="flex items-center gap-1 font-hand text-sm text-[#6b584c] hover:text-[#3d2b21] cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Start from beginning</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyLink}
            className="flex items-center gap-1 font-hand text-sm text-[#6b584c] hover:text-[#3d2b21] cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#2c5e3b]" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copied ? 'Link copied' : 'Copy link'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
