import React, { useState } from 'react';
import { X, Save, RotateCcw, Upload, Plus, Trash2, Download, FileUp, Check } from 'lucide-react';
import { GiftStoryConfig, PhotoItem } from '../types';
import { resetGiftConfig } from '../utils/storage';
import { compressImageFile } from '../utils/imageCompressor';

interface EditGiftModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: GiftStoryConfig;
  onSave: (updated: GiftStoryConfig) => void;
}

export const EditGiftModal: React.FC<EditGiftModalProps> = ({
  isOpen,
  onClose,
  config,
  onSave,
}) => {
  const [formData, setFormData] = useState<GiftStoryConfig>(config);
  const [activeTab, setActiveTab] = useState<'basics' | 'photos' | 'fireplace' | 'letter'>('basics');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>, id: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const compressedDataUrl = await compressImageFile(file);
      setFormData((prev) => ({
        ...prev,
        photos: prev.photos.map((p) => (p.id === id ? { ...p, url: compressedDataUrl } : p)),
      }));
    } catch {
      // Fallback
    }
  };

  const handleAddPhoto = () => {
    const newPhoto: PhotoItem = {
      id: `photo-${Date.now()}`,
      url: '/src/assets/images/couple_holiday_walk_1793776857970.jpg',
      caption: 'Another sweet memory',
      date: 'December',
      location: 'Together',
    };
    setFormData((prev) => ({
      ...prev,
      photos: [...prev.photos, newPhoto],
    }));
  };

  const handleRemovePhoto = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      photos: prev.photos.filter((p) => p.id !== id),
    }));
  };

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(formData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', 'christmas-gift-config.json');
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    setStatusMsg('Saved backup file!');
    setTimeout(() => setStatusMsg(null), 3000);
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        setFormData(parsed);
        setStatusMsg('Loaded config!');
        setTimeout(() => setStatusMsg(null), 3000);
      } catch (err) {
        alert('Invalid JSON file format.');
      }
    };
    reader.readAsText(file);
  };

  const handleReset = () => {
    if (confirm('Reset to original sample photos and text?')) {
      const reset = resetGiftConfig();
      setFormData(reset);
      onSave(reset);
      setStatusMsg('Reset to default.');
      setTimeout(() => setStatusMsg(null), 3000);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#3d2f26]/30 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-2xl paper-box-warm overflow-hidden flex flex-col max-h-[88vh] shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-[#ebd9c2] bg-[#fffdfa]">
          <div>
            <h3 className="text-2xl font-script font-bold text-[#423226]">
              Personalize your gift
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#8f7d6f] hover:text-[#3e322b] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status notification */}
        {statusMsg && (
          <div className="bg-[#eef5ed] text-[#2c5e3b] font-hand text-base px-6 py-1.5 border-b border-[#cde0d1] flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>{statusMsg}</span>
          </div>
        )}

        {/* Clean, light paper tab bar */}
        <div className="flex items-center gap-2 px-6 py-2 border-b border-[#ebd9c2] bg-[#fbf7f0] overflow-x-auto text-base font-hand">
          {[
            { id: 'basics', label: 'Names & Intro' },
            { id: 'photos', label: `Mantle Photos (${formData.photos.length})` },
            { id: 'fireplace', label: 'Fireplace' },
            { id: 'letter', label: 'Letter' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`px-3.5 py-1 rounded-full whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-[#9e2a2b] text-[#fffdfa] shadow-xs'
                  : 'text-[#6b584a] hover:bg-[#ede3d5]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-left font-hand text-base">
          {activeTab === 'basics' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[#544135] font-semibold mb-1">
                    Boyfriend's Name
                  </label>
                  <input
                    type="text"
                    value={formData.recipientName}
                    onChange={(e) => setFormData({ ...formData, recipientName: e.target.value })}
                    className="w-full px-3 py-2 bg-[#fffdfa] text-[#3e322b] border border-[#ebd9c2] rounded-xl text-lg font-hand focus:outline-none"
                    placeholder="e.g. Alex"
                  />
                </div>
                <div>
                  <label className="block text-[#544135] font-semibold mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    value={formData.senderName}
                    onChange={(e) => setFormData({ ...formData, senderName: e.target.value })}
                    className="w-full px-3 py-2 bg-[#fffdfa] text-[#3e322b] border border-[#ebd9c2] rounded-xl text-lg font-hand focus:outline-none"
                    placeholder="e.g. Maya"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#544135] font-semibold mb-1">
                  Cottage Door Question
                </label>
                <input
                  type="text"
                  value={formData.cottageQuestion}
                  onChange={(e) => setFormData({ ...formData, cottageQuestion: e.target.value })}
                  className="w-full px-3 py-2 bg-[#fffdfa] text-[#3e322b] border border-[#ebd9c2] rounded-xl text-lg font-hand focus:outline-none"
                  placeholder="Would you like to go inside?"
                />
              </div>

              <div>
                <label className="block text-[#544135] font-semibold mb-1">
                  Cottage Door Button Text
                </label>
                <input
                  type="text"
                  value={formData.cottageButtonText}
                  onChange={(e) => setFormData({ ...formData, cottageButtonText: e.target.value })}
                  className="w-full px-3 py-2 bg-[#fffdfa] text-[#3e322b] border border-[#ebd9c2] rounded-xl text-lg font-hand focus:outline-none"
                  placeholder="Open the door"
                />
              </div>

              <div>
                <label className="block text-[#544135] font-semibold mb-1">
                  Last Slide Note
                </label>
                <textarea
                  rows={2}
                  value={formData.loveYouSubtext}
                  onChange={(e) => setFormData({ ...formData, loveYouSubtext: e.target.value })}
                  className="w-full px-3 py-2 bg-[#fffdfa] text-[#3e322b] border border-[#ebd9c2] rounded-xl text-lg font-hand focus:outline-none"
                  placeholder="Sweet note on the last page..."
                />
              </div>
            </div>
          )}

          {activeTab === 'photos' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[#544135] font-semibold">
                  Mantle Photos
                </span>
                <button
                  type="button"
                  onClick={handleAddPhoto}
                  className="flex items-center gap-1 px-3 py-1 bg-[#fffdfa] border border-[#ebd9c2] text-[#852526] rounded-full hover:bg-[#faf5eb] cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add photo</span>
                </button>
              </div>

              <div className="space-y-3">
                {formData.photos.map((photo, idx) => (
                  <div
                    key={photo.id}
                    className="p-3 bg-[#fffdfa] border border-[#ebd9c2] rounded-xl flex flex-col sm:flex-row gap-3 items-center"
                  >
                    <div className="relative w-24 aspect-[4/3] rounded-lg overflow-hidden bg-[#e8ded0] border border-[#d2c0aa] shrink-0">
                      <img
                        src={photo.url}
                        alt={photo.caption}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <label className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 flex items-center justify-center text-white cursor-pointer transition-opacity">
                        <Upload className="w-4 h-4" />
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => handlePhotoUpload(e, photo.id)}
                        />
                      </label>
                    </div>

                    <div className="flex-1 w-full space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[#852526] font-bold">Picture #{idx + 1}</span>
                        {formData.photos.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemovePhoto(photo.id)}
                            className="text-[#9e2a2b] hover:text-[#6e1c1d] p-1"
                            title="Remove"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      <input
                        type="text"
                        value={photo.caption}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            photos: formData.photos.map((p) =>
                              p.id === photo.id ? { ...p, caption: e.target.value } : p
                            ),
                          })
                        }
                        className="w-full px-2.5 py-1 bg-[#faf5eb] border border-[#ebd9c2] rounded-lg text-[#3e322b] text-base font-hand focus:outline-none"
                        placeholder="Caption..."
                      />

                      <div className="flex items-center gap-2">
                        <label className="text-sm font-hand text-[#852526] hover:underline cursor-pointer flex items-center gap-1">
                          <Upload className="w-3 h-3" />
                          <span>Change photo file</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => handlePhotoUpload(e, photo.id)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'fireplace' && (
            <div className="space-y-4">
              <div>
                <label className="block text-[#544135] font-semibold mb-1">
                  Fireplace Quote
                </label>
                <textarea
                  rows={2}
                  value={formData.fireplaceQuote}
                  onChange={(e) => setFormData({ ...formData, fireplaceQuote: e.target.value })}
                  className="w-full px-3 py-2 bg-[#fffdfa] text-[#3e322b] font-script text-2xl border border-[#ebd9c2] rounded-xl focus:outline-none"
                  placeholder="for all the times we pretended and ate like we were living here"
                />
              </div>

              <div>
                <label className="block text-[#544135] font-semibold mb-1">
                  Fireplace Subtext
                </label>
                <textarea
                  rows={2}
                  value={formData.fireplaceSubtext}
                  onChange={(e) => setFormData({ ...formData, fireplaceSubtext: e.target.value })}
                  className="w-full px-3 py-2 bg-[#fffdfa] text-[#544135] border border-[#ebd9c2] rounded-xl text-lg font-hand focus:outline-none"
                  placeholder="Sweet subtext..."
                />
              </div>
            </div>
          )}

          {activeTab === 'letter' && (
            <div className="space-y-4">
              <div>
                <label className="block text-[#544135] font-semibold mb-1">
                  Envelope Title
                </label>
                <input
                  type="text"
                  value={formData.letterEnvelopeTitle}
                  onChange={(e) => setFormData({ ...formData, letterEnvelopeTitle: e.target.value })}
                  className="w-full px-3 py-2 bg-[#fffdfa] text-[#852526] font-script text-2xl border border-[#ebd9c2] rounded-xl focus:outline-none"
                  placeholder="Merry Christmas"
                />
              </div>

              <div>
                <label className="block text-[#544135] font-semibold mb-1">
                  Greeting
                </label>
                <input
                  type="text"
                  value={formData.letterGreeting}
                  onChange={(e) => setFormData({ ...formData, letterGreeting: e.target.value })}
                  className="w-full px-3 py-2 bg-[#fffdfa] text-[#3e322b] font-script text-2xl border border-[#ebd9c2] rounded-xl focus:outline-none"
                  placeholder="My Dearest Love,"
                />
              </div>

              <div>
                <label className="block text-[#544135] font-semibold mb-1">
                  Letter Message
                </label>
                <textarea
                  rows={8}
                  value={formData.letterBody}
                  onChange={(e) => setFormData({ ...formData, letterBody: e.target.value })}
                  className="w-full px-3 py-2 bg-[#fffdfa] text-[#3e322b] border border-[#ebd9c2] rounded-xl text-lg font-hand leading-relaxed focus:outline-none"
                  placeholder="Write your letter here..."
                />
              </div>

              <div>
                <label className="block text-[#544135] font-semibold mb-1">
                  Sign-off
                </label>
                <input
                  type="text"
                  value={formData.letterSignoff}
                  onChange={(e) => setFormData({ ...formData, letterSignoff: e.target.value })}
                  className="w-full px-3 py-2 bg-[#fffdfa] text-[#852526] font-script text-2xl border border-[#ebd9c2] rounded-xl focus:outline-none"
                  placeholder="With all my love, always and forever ♡"
                />
              </div>
            </div>
          )}

          {/* Backup bar */}
          <div className="pt-3 border-t border-[#ebd9c2] flex items-center justify-between text-sm">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleExportJson}
                className="text-[#6b584a] hover:text-[#3e322b] flex items-center gap-1 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export backup</span>
              </button>

              <span className="text-[#ebd9c2]">|</span>

              <label className="text-[#6b584a] hover:text-[#3e322b] flex items-center gap-1 cursor-pointer">
                <FileUp className="w-3.5 h-3.5" />
                <span>Import backup</span>
                <input
                  type="file"
                  accept="application/json"
                  className="hidden"
                  onChange={handleImportJson}
                />
              </label>
            </div>

            <button
              type="button"
              onClick={handleReset}
              className="text-[#9e2a2b] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>
        </form>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-3.5 bg-[#fffdfa] border-t border-[#ebd9c2]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 font-hand text-base text-[#6b584a] cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            className="flex items-center gap-1.5 px-6 py-1.5 font-hand text-lg paper-btn-festive rounded-full cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save gift</span>
          </button>
        </div>
      </div>
    </div>
  );
};
