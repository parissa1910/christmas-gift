import React, { useState, useRef, useEffect } from 'react';
import { X, RotateCcw, ArrowRight } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';

interface FlyingSnowball {
  id: number;
  startX: number;
  startY: number;
  targetX: number;
  targetY: number;
  progress: number;
  scale: number;
  hitTarget?: 'snowman' | 'tree' | 'ground';
}

interface SplatEffect {
  id: number;
  x: number;
  y: number;
  size: number;
}

interface FloatingText {
  id: number;
  text: string;
  x: number;
  y: number;
}

export const SnowballGameModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onGoInside: () => void;
}> = ({ isOpen, onClose, onGoInside }) => {
  const [hits, setHits] = useState<number>(0);
  const [snowmanMood, setSnowmanMood] = useState<'happy' | 'hit'>('happy');
  const [snowmanComment, setSnowmanComment] = useState<string>('Toss a snowball at me!');
  const [flyingSnowballs, setFlyingSnowballs] = useState<FlyingSnowball[]>([]);
  const [splats, setSplats] = useState<SplatEffect[]>([]);
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);
  const [isTreeWobbling, setIsTreeWobbling] = useState<boolean>(false);
  const arenaRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    let animId: number;
    const update = () => {
      setFlyingSnowballs((prev) => {
        if (prev.length === 0) return prev;
        const remaining: FlyingSnowball[] = [];

        prev.forEach((ball) => {
          const nextProgress = ball.progress + 0.05;
          if (nextProgress >= 1) {
            handleSnowballImpact(ball);
          } else {
            remaining.push({
              ...ball,
              progress: nextProgress,
              scale: 1 - nextProgress * 0.45,
            });
          }
        });

        return remaining;
      });

      animId = requestAnimationFrame(update);
    };

    animId = requestAnimationFrame(update);
    return () => cancelAnimationFrame(animId);
  }, [isOpen]);

  const handleSnowballImpact = (ball: FlyingSnowball) => {
    audioEngine.playSnowballHit();

    const newSplat: SplatEffect = {
      id: Date.now() + Math.random(),
      x: ball.targetX,
      y: ball.targetY,
      size: Math.random() * 12 + 24,
    };

    setSplats((prev) => [...prev.slice(-10), newSplat]);

    if (ball.hitTarget === 'snowman') {
      setHits((h) => h + 1);
      setSnowmanMood('hit');
      const lines = [
        'Direct hit! ⛄',
        'Right on the carrot! 🥕',
        'Cold cold cold! Haha!',
        'Good throw! 🤍',
      ];
      setSnowmanComment(lines[Math.floor(Math.random() * lines.length)]);
      addFloatingText('Poof! 🎯', ball.targetX, ball.targetY - 20);
      setTimeout(() => setSnowmanMood('happy'), 800);
    } else if (ball.hitTarget === 'tree') {
      setHits((h) => h + 1);
      setIsTreeWobbling(true);
      addFloatingText('Jingle! 🎄', ball.targetX, ball.targetY - 20);
      setTimeout(() => setIsTreeWobbling(false), 700);
    } else {
      addFloatingText('Splat! ❄️', ball.targetX, ball.targetY - 10);
    }
  };

  const addFloatingText = (text: string, x: number, y: number) => {
    const id = Date.now() + Math.random();
    setFloatingTexts((prev) => [...prev, { id, text, x, y }]);
    setTimeout(() => {
      setFloatingTexts((prev) => prev.filter((item) => item.id !== id));
    }, 1000);
  };

  const handleArenaClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!arenaRef.current) return;
    const rect = arenaRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const snowmanX = rect.width * 0.38;
    const snowmanY = rect.height * 0.58;
    const distToSnowman = Math.hypot(clickX - snowmanX, clickY - snowmanY);

    const treeX = rect.width * 0.72;
    const treeY = rect.height * 0.52;
    const distToTree = Math.hypot(clickX - treeX, clickY - treeY);

    let hitTarget: 'snowman' | 'tree' | 'ground' = 'ground';
    if (distToSnowman < 75) {
      hitTarget = 'snowman';
    } else if (distToTree < 90) {
      hitTarget = 'tree';
    }

    audioEngine.playSnowballThrow();

    const startX = rect.width * 0.5;
    const startY = rect.height * 0.95;

    const newBall: FlyingSnowball = {
      id: Date.now() + Math.random(),
      startX,
      startY,
      targetX: clickX,
      targetY: clickY,
      progress: 0,
      scale: 1,
      hitTarget,
    };

    setFlyingSnowballs((prev) => [...prev, newBall]);
  };

  const resetGame = () => {
    setHits(0);
    setSplats([]);
    setSnowmanComment('Toss a snowball at me!');
    setSnowmanMood('happy');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-5 bg-[#3d2f26]/30 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-2xl paper-box-warm overflow-hidden flex flex-col shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-2.5 border-b border-[#e9dfd1] bg-[#fffdfa]">
          <div className="flex items-center gap-1.5">
            <span className="text-xl">⛄</span>
            <h3 className="text-xl font-script font-bold text-[#423226]">
              Playing in the snow
            </h3>
          </div>

          <div className="flex items-center gap-2.5">
            <span className="font-hand text-sm text-[#6b584a]">
              Hits: <strong className="text-[#852526]">{hits}</strong>
            </span>
            <button
              onClick={resetGame}
              className="p-1 text-[#8f7d6f] hover:text-[#3e322b] cursor-pointer"
              title="Reset"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onClose}
              className="p-1 text-[#8f7d6f] hover:text-[#3e322b] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Soft, light watercolor snowy yard arena */}
        <div
          ref={arenaRef}
          onClick={handleArenaClick}
          className="relative w-full h-[320px] md:h-[370px] bg-gradient-to-b from-[#e3edf7] via-[#eff5fa] to-[#fbf8f4] overflow-hidden cursor-crosshair select-none"
        >
          {/* Soft storybook pine silhouettes */}
          <div className="absolute inset-x-0 bottom-8 h-28 opacity-40 flex justify-around pointer-events-none">
            <div className="w-12 h-24 bg-[#95b5a0] rounded-t-full"></div>
            <div className="w-16 h-32 bg-[#83a68f] rounded-t-full"></div>
            <div className="w-12 h-20 bg-[#95b5a0] rounded-t-full"></div>
            <div className="w-18 h-32 bg-[#83a68f] rounded-t-full"></div>
          </div>

          {/* Snowy ground mound */}
          <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-[#ffffff] via-[#f5f8fc] to-[#e8f0f8] rounded-t-[50%] scale-x-125 border-t border-[#dce8f4] pointer-events-none"></div>

          {/* Hand-drawn style Snowman */}
          <div
            className={`absolute left-[36%] bottom-14 -translate-x-1/2 flex flex-col items-center pointer-events-none transition-transform duration-300 ${
              snowmanMood === 'hit' ? 'scale-95 rotate-3' : 'animate-sway'
            }`}
          >
            {/* Speech bubble */}
            <div className="mb-1.5 px-2.5 py-0.5 bg-[#fffdf9] text-[#423226] text-sm font-hand rounded-full shadow-xs border border-[#e5dcd1]">
              {snowmanComment}
            </div>

            {/* Hat */}
            <div className="w-10 h-8 bg-[#3d322a] rounded-t-md border-b-2 border-[#9e2a2b]"></div>
            <div className="w-14 h-1.5 bg-[#3d322a] rounded-full -mt-0.5"></div>

            {/* Head */}
            <div className="relative w-13 h-13 bg-[#ffffff] rounded-full border border-[#d6e3ee] shadow-xs flex items-center justify-center -mt-1">
              <div className="absolute top-3.5 left-3 w-1.5 h-1.5 bg-[#3d322a] rounded-full"></div>
              <div className="absolute top-3.5 right-3 w-1.5 h-1.5 bg-[#3d322a] rounded-full"></div>
              <div className="absolute top-5 w-4.5 h-2 bg-gradient-to-r from-[#d97706] to-[#ea580c] rounded-r-full rotate-6"></div>
            </div>

            {/* Cozy red scarf */}
            <div className="w-16 h-3 bg-[#a33233] rounded-full shadow-xs -mt-1.5 z-10 flex justify-end">
              <div className="w-3 h-6 bg-[#a33233] rounded-b-md mr-1.5"></div>
            </div>

            {/* Middle */}
            <div className="relative w-19 h-19 bg-[#ffffff] rounded-full border border-[#d6e3ee] shadow-xs flex flex-col items-center justify-center -mt-1">
              <div className="w-1.5 h-1.5 bg-[#3d322a] rounded-full mb-1"></div>
              <div className="w-1.5 h-1.5 bg-[#3d322a] rounded-full"></div>
              {/* Twig arms */}
              <div className="absolute -left-5 top-4 w-6 h-1 bg-[#78543d] -rotate-25 rounded-full"></div>
              <div className="absolute -right-5 top-4 w-6 h-1 bg-[#78543d] rotate-25 rounded-full"></div>
            </div>

            {/* Bottom Ball */}
            <div className="w-24 h-24 bg-[#fdfdfd] rounded-full border border-[#d6e3ee] shadow-sm -mt-2"></div>
          </div>

          {/* Hand-drawn style Christmas Tree Target */}
          <div
            className={`absolute right-[20%] bottom-14 flex flex-col items-center pointer-events-none transition-transform duration-200 ${
              isTreeWobbling ? 'scale-105 -rotate-2' : ''
            }`}
          >
            <div className="text-lg">⭐</div>
            <div className="w-16 h-12 bg-[#5a8769] rounded-t-full relative -mt-1">
              <div className="w-2 h-2 bg-[#c54b4b] rounded-full absolute top-4 left-2.5"></div>
            </div>
            <div className="w-24 h-15 bg-[#4e795c] rounded-t-full relative -mt-4">
              <div className="w-2 h-2 bg-[#e4ab44] rounded-full absolute top-5 right-4"></div>
            </div>
            <div className="w-32 h-17 bg-[#426b4f] rounded-t-full relative -mt-5">
              <div className="w-2 h-2 bg-[#c54b4b] rounded-full absolute top-7 left-5"></div>
              <div className="w-2 h-2 bg-[#e4ab44] rounded-full absolute top-8 right-6"></div>
            </div>
            <div className="w-6 h-6 bg-[#6d4c38] rounded-b-sm -mt-1"></div>
          </div>

          {/* Splats */}
          {splats.map((splat) => (
            <div
              key={splat.id}
              className="absolute pointer-events-none transform -translate-x-1/2 -translate-y-1/2"
              style={{ left: splat.x, top: splat.y }}
            >
              <div
                className="bg-[#ffffff]/90 rounded-full border border-[#e1eaf3] shadow-xs"
                style={{ width: splat.size, height: splat.size }}
              />
            </div>
          ))}

          {/* Flying Snowballs */}
          {flyingSnowballs.map((ball) => {
            const currentX = ball.startX + (ball.targetX - ball.startX) * ball.progress;
            const arcHeight = 90 * Math.sin(ball.progress * Math.PI);
            const currentY = ball.startY + (ball.targetY - ball.startY) * ball.progress - arcHeight;

            return (
              <div
                key={ball.id}
                className="absolute pointer-events-none transform -translate-x-1/2 -translate-y-1/2 z-30"
                style={{
                  left: currentX,
                  top: currentY,
                  transform: `translate(-50%, -50%) scale(${ball.scale})`,
                }}
              >
                <div className="w-7 h-7 bg-gradient-to-tr from-[#e5f0fa] to-[#ffffff] rounded-full shadow-md border border-[#d6e3ee]" />
              </div>
            );
          })}

          {/* Floating score text */}
          {floatingTexts.map((ft) => (
            <div
              key={ft.id}
              className="absolute pointer-events-none transform -translate-x-1/2 -translate-y-1/2 font-hand text-base font-bold text-[#852526] z-40 transition-all duration-700 animate-fade-out"
              style={{ left: ft.x, top: ft.y }}
            >
              {ft.text}
            </div>
          ))}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-5 py-2.5 bg-[#fffdfa] border-t border-[#ebd9c2]">
          <button
            onClick={onClose}
            className="px-3.5 py-1 font-hand text-sm text-[#6b584a] paper-btn rounded-full cursor-pointer"
          >
            Back to yard
          </button>
          <button
            onClick={() => {
              onClose();
              onGoInside();
            }}
            className="flex items-center gap-1.5 px-5 py-1 font-hand text-base paper-btn-festive rounded-full cursor-pointer"
          >
            <span>Step inside</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
