/**
 * Pure Web Audio API Synthesizer for Christmas Music Box & Sound Effects
 * Completely self-contained, offline-capable, and non-intrusive.
 */

class ChristmasAudioEngine {
  private ctx: AudioContext | null = null;
  private musicGainNode: GainNode | null = null;
  private sfxGainNode: GainNode | null = null;
  private isMusicEnabled: boolean = false;
  private isMuted: boolean = false;
  private musicTimeoutId: number | null = null;
  private noteIndex: number = 0;
  private fireIntervalId: number | null = null;

  // Music notes for Silent Night & We Wish You a Merry Christmas
  // Note format: [midiNote, durationInBeats]
  private readonly melodyNotes: [number, number][] = [
    // Silent Night
    [67, 1.5], [69, 0.5], [67, 1.0], [64, 2.0], // G4, A4, G4, E4
    [67, 1.5], [69, 0.5], [67, 1.0], [64, 2.0], // G4, A4, G4, E4
    [74, 2.0], [74, 1.0], [71, 3.0],             // D5, D5, B4
    [72, 2.0], [72, 1.0], [67, 3.0],             // C5, C5, G4
    [69, 2.0], [69, 1.0], [72, 1.5], [71, 0.5], [69, 1.0], [67, 1.5], [69, 0.5], [67, 1.0], [64, 2.0], // A4...
    [69, 2.0], [69, 1.0], [72, 1.5], [71, 0.5], [69, 1.0], [67, 1.5], [69, 0.5], [67, 1.0], [64, 2.0],
    [74, 2.0], [74, 1.0], [77, 1.5], [74, 0.5], [71, 1.0], [72, 3.0], [76, 3.0], // D5.. F5 D5 B4 C5 E5
    [72, 1.5], [67, 0.5], [64, 1.0], [67, 1.5], [65, 0.5], [62, 1.0], [60, 4.0], // C5 G4 E4 G4 F4 D4 C4

    // Short festive chime interlude
    [72, 0.5], [76, 0.5], [79, 0.5], [84, 1.5],

    // We Wish You A Merry Christmas
    [62, 1.0], // D4
    [67, 1.0], [67, 0.5], [69, 0.5], [67, 0.5], [66, 0.5], // G4, G4, A4, G4, F#4
    [64, 1.0], [64, 1.0], [64, 1.0], // E4, E4, E4
    [69, 1.0], [69, 0.5], [71, 0.5], [69, 0.5], [67, 0.5], // A4, A4, B4, A4, G4
    [66, 1.0], [62, 1.0], [62, 1.0], // F#4, D4, D4
    [71, 1.0], [71, 0.5], [72, 0.5], [71, 0.5], [69, 0.5], // B4, B4, C5, B4, A4
    [67, 1.0], [64, 1.0], [62, 0.5], [62, 0.5], // G4, E4, D4, D4
    [64, 1.0], [69, 1.0], [66, 1.0], [67, 3.0], // E4, A4, F#4, G4
  ];

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();

      // Music Gain node
      this.musicGainNode = this.ctx.createGain();
      this.musicGainNode.gain.setValueAtTime(0.12, this.ctx.currentTime);

      // SFX Gain node
      this.sfxGainNode = this.ctx.createGain();
      this.sfxGainNode.gain.setValueAtTime(0.25, this.ctx.currentTime);

      this.musicGainNode.connect(this.ctx.destination);
      this.sfxGainNode.connect(this.ctx.destination);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  // Convert MIDI note number to frequency in Hz
  private midiToFreq(midi: number): number {
    return 440 * Math.pow(2, (midi - 69) / 12);
  }

  // Play a single bell / celesta note
  private playMusicBoxNote(midi: number, durationSec: number) {
    const ctx = this.getContext();
    if (!ctx || !this.musicGainNode || this.isMuted) return;

    const now = ctx.currentTime;
    const freq = this.midiToFreq(midi);

    // Fundamental oscillator (sine)
    const osc1 = ctx.createOscillator();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(freq, now);

    // Overtone oscillator (triangle with subtle detune for music-box chime feel)
    const osc2 = ctx.createOscillator();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(freq * 2.01, now);

    // Bell envelope
    const noteGain = ctx.createGain();
    noteGain.gain.setValueAtTime(0, now);
    noteGain.gain.linearRampToValueAtTime(0.7, now + 0.015);
    noteGain.gain.exponentialRampToValueAtTime(0.001, now + Math.max(0.6, durationSec * 1.5));

    // Secondary subtle sparkle envelope
    const overtoneGain = ctx.createGain();
    overtoneGain.gain.setValueAtTime(0, now);
    overtoneGain.gain.linearRampToValueAtTime(0.25, now + 0.01);
    overtoneGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.4);

    // Lowpass filter for warm, cozy acoustics
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(2800, now);

    osc1.connect(noteGain);
    osc2.connect(overtoneGain);
    overtoneGain.connect(noteGain);
    noteGain.connect(filter);
    filter.connect(this.musicGainNode);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + durationSec * 1.8);
    osc2.stop(now + durationSec * 1.8);
  }

  private scheduleNextMelodyStep = () => {
    if (!this.isMusicEnabled || this.isMuted) return;

    const beatDuration = 0.48; // Tempo ~125 BPM
    const [midi, beats] = this.melodyNotes[this.noteIndex];
    const durationSec = beats * beatDuration;

    this.playMusicBoxNote(midi, durationSec);

    // Advance note index
    this.noteIndex = (this.noteIndex + 1) % this.melodyNotes.length;

    // Schedule next note
    this.musicTimeoutId = window.setTimeout(this.scheduleNextMelodyStep, durationSec * 1000);
  };

  public toggleMusic(): boolean {
    const ctx = this.getContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    if (this.isMusicEnabled) {
      this.isMusicEnabled = false;
      if (this.musicTimeoutId !== null) {
        clearTimeout(this.musicTimeoutId);
        this.musicTimeoutId = null;
      }
      return false;
    } else {
      this.isMusicEnabled = true;
      this.scheduleNextMelodyStep();
      return true;
    }
  }

  public isMusicOn(): boolean {
    return this.isMusicEnabled && !this.isMuted;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    const ctx = this.getContext();
    if (ctx && this.musicGainNode && this.sfxGainNode) {
      const targetGain = this.isMuted ? 0 : 0.12;
      const targetSfx = this.isMuted ? 0 : 0.25;
      this.musicGainNode.gain.setValueAtTime(targetGain, ctx.currentTime);
      this.sfxGainNode.gain.setValueAtTime(targetSfx, ctx.currentTime);
    }
    return this.isMuted;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  // --- SOUND EFFECTS ---

  /**
   * Sound of cottage door opening: gentle wooden creak followed by welcoming holiday chime
   */
  public playDoorOpenSound() {
    const ctx = this.getContext();
    if (!ctx || !this.sfxGainNode || this.isMuted) return;

    const now = ctx.currentTime;

    // 1. Wood creak (filtered saw with pitch modulation)
    const creakOsc = ctx.createOscillator();
    creakOsc.type = 'sawtooth';
    creakOsc.frequency.setValueAtTime(120, now);
    creakOsc.frequency.linearRampToValueAtTime(190, now + 0.35);
    creakOsc.frequency.exponentialRampToValueAtTime(90, now + 0.7);

    const creakGain = ctx.createGain();
    creakGain.gain.setValueAtTime(0, now);
    creakGain.gain.linearRampToValueAtTime(0.08, now + 0.1);
    creakGain.gain.exponentialRampToValueAtTime(0.001, now + 0.75);

    const creakFilter = ctx.createBiquadFilter();
    creakFilter.type = 'bandpass';
    creakFilter.frequency.setValueAtTime(350, now);
    creakFilter.Q.setValueAtTime(3.0, now);

    creakOsc.connect(creakFilter);
    creakFilter.connect(creakGain);
    creakGain.connect(this.sfxGainNode);

    creakOsc.start(now);
    creakOsc.stop(now + 0.8);

    // 2. Door bell / porch chime
    const playChime = (freq: number, delay: number) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + delay);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0, now + delay);
      gain.gain.linearRampToValueAtTime(0.15, now + delay + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 1.2);

      osc.connect(gain);
      gain.connect(this.sfxGainNode!);

      osc.start(now + delay);
      osc.stop(now + delay + 1.3);
    };

    playChime(659.25, 0.25); // E5
    playChime(987.77, 0.45); // B5
    playChime(1318.51, 0.65); // E6
  }

  /**
   * Sound of snowflakes falling / gentle sparkling chime
   */
  public playSnowflakeSparkle() {
    const ctx = this.getContext();
    if (!ctx || !this.sfxGainNode || this.isMuted) return;

    const now = ctx.currentTime;
    const notes = [1046.5, 1318.5, 1567.98, 2093.0]; // C6, E6, G6, C7
    const randomNote = notes[Math.floor(Math.random() * notes.length)];

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(randomNote, now);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.06, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.5);

    osc.connect(gain);
    gain.connect(this.sfxGainNode);

    osc.start(now);
    osc.stop(now + 0.55);
  }

  /**
   * Sound of opening the wax-sealed letter: seal snap + paper unfolding rustle
   */
  public playLetterOpenSound() {
    const ctx = this.getContext();
    if (!ctx || !this.sfxGainNode || this.isMuted) return;

    const now = ctx.currentTime;

    // 1. Wax seal crack (sharp filtered noise snap)
    const bufferSize = ctx.sampleRate * 0.1;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;

    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.setValueAtTime(1400, now);
    noiseFilter.Q.setValueAtTime(2.0, now);

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.2, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

    whiteNoise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.sfxGainNode);

    whiteNoise.start(now);

    // 2. Paper slide / rustle
    const paperBufferSize = Math.floor(ctx.sampleRate * 0.4);
    const paperBuffer = ctx.createBuffer(1, paperBufferSize, ctx.sampleRate);
    const pOut = paperBuffer.getChannelData(0);
    for (let i = 0; i < paperBufferSize; i++) {
      pOut[i] = (Math.random() * 2 - 1) * Math.sin((i / paperBufferSize) * Math.PI);
    }

    const paperNoise = ctx.createBufferSource();
    paperNoise.buffer = paperBuffer;

    const paperFilter = ctx.createBiquadFilter();
    paperFilter.type = 'lowpass';
    paperFilter.frequency.setValueAtTime(800, now + 0.08);

    const paperGain = ctx.createGain();
    paperGain.gain.setValueAtTime(0, now + 0.08);
    paperGain.gain.linearRampToValueAtTime(0.09, now + 0.15);
    paperGain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    paperNoise.connect(paperFilter);
    paperFilter.connect(paperGain);
    paperGain.connect(this.sfxGainNode);

    paperNoise.start(now + 0.08);

    // 3. Gentle sweet chime to accompany the reveal
    const bellOsc = ctx.createOscillator();
    bellOsc.type = 'sine';
    bellOsc.frequency.setValueAtTime(880, now + 0.2); // A5

    const bellGain = ctx.createGain();
    bellGain.gain.setValueAtTime(0, now + 0.2);
    bellGain.gain.linearRampToValueAtTime(0.12, now + 0.23);
    bellGain.gain.exponentialRampToValueAtTime(0.001, now + 1.1);

    bellOsc.connect(bellGain);
    bellGain.connect(this.sfxGainNode);

    bellOsc.start(now + 0.2);
    bellOsc.stop(now + 1.2);
  }

  /**
   * Snowball throw: soft swoosh arc sound
   */
  public playSnowballThrow() {
    const ctx = this.getContext();
    if (!ctx || !this.sfxGainNode || this.isMuted) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(400, now);
    osc.frequency.exponentialRampToValueAtTime(150, now + 0.25);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.01, now);
    gain.gain.linearRampToValueAtTime(0.14, now + 0.08);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

    osc.connect(gain);
    gain.connect(this.sfxGainNode);

    osc.start(now);
    osc.stop(now + 0.3);
  }

  /**
   * Snowball hit: soft powdery "poof / splat" sound
   */
  public playSnowballHit() {
    const ctx = this.getContext();
    if (!ctx || !this.sfxGainNode || this.isMuted) return;

    const now = ctx.currentTime;
    const bufferSize = Math.floor(ctx.sampleRate * 0.2);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.04));
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(600, now);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGainNode);

    noise.start(now);

    // Add a cute little jingle chime on snowman hit
    const bell = ctx.createOscillator();
    bell.type = 'sine';
    bell.frequency.setValueAtTime(1174.66, now); // D6
    const bGain = ctx.createGain();
    bGain.gain.setValueAtTime(0.08, now);
    bGain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

    bell.connect(bGain);
    bGain.connect(this.sfxGainNode);
    bell.start(now);
    bell.stop(now + 0.35);
  }

  /**
   * Heart pop / loving touch sound
   */
  public playHeartSound() {
    const ctx = this.getContext();
    if (!ctx || !this.sfxGainNode || this.isMuted) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(523.25, now); // C5
    osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.18); // G5

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.12, now + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc.connect(gain);
    gain.connect(this.sfxGainNode);

    osc.start(now);
    osc.stop(now + 0.45);
  }

  /**
   * Ambient fireplace subtle crackle (gentle background clicks)
   */
  public startFireCrackle() {
    if (this.fireIntervalId !== null) return;
    this.fireIntervalId = window.setInterval(() => {
      if (this.isMuted) return;
      // Random gentle pop
      if (Math.random() < 0.4) {
        const ctx = this.getContext();
        if (!ctx || !this.sfxGainNode) return;
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(200 + Math.random() * 400, now);
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.03, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.04);
        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(now);
        osc.stop(now + 0.05);
      }
    }, 280);
  }

  public stopFireCrackle() {
    if (this.fireIntervalId !== null) {
      clearInterval(this.fireIntervalId);
      this.fireIntervalId = null;
    }
  }
}

export const audioEngine = new ChristmasAudioEngine();
