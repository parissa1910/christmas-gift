import { GiftStoryConfig } from '../types';
import { DEFAULT_GIFT_CONFIG } from './defaultData';

const STORAGE_KEY = 'cozy_christmas_gift_data_v2';
const IDB_NAME = 'MerryChristmasGiftDB';
const IDB_STORE = 'gift_store';
const IDB_KEY = 'current_gift_config';

/**
 * Lightweight native IndexedDB wrapper for large payload persistence (images, full gift config)
 */
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not available'));
      return;
    }
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) {
        db.createObjectStore(IDB_STORE);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function idbSaveConfig(config: GiftStoryConfig): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      const store = tx.objectStore(IDB_STORE);
      store.put(config, IDB_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // Graceful silent fallback
  }
}

export async function idbLoadConfig(): Promise<GiftStoryConfig | null> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const store = tx.objectStore(IDB_STORE);
      const req = store.get(IDB_KEY);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

/**
 * Synchronous loader for initial render (from localStorage)
 */
export function loadGiftConfig(): GiftStoryConfig {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return DEFAULT_GIFT_CONFIG;
    const parsed = JSON.parse(saved);
    return {
      ...DEFAULT_GIFT_CONFIG,
      ...parsed,
      photos: parsed.photos && parsed.photos.length > 0 ? parsed.photos : DEFAULT_GIFT_CONFIG.photos,
    };
  } catch {
    return DEFAULT_GIFT_CONFIG;
  }
}

/**
 * Async loader that restores from IndexedDB if available (contains full compressed photos)
 */
export async function loadGiftConfigAsync(): Promise<GiftStoryConfig> {
  const fromIdb = await idbLoadConfig();
  if (fromIdb) {
    return {
      ...DEFAULT_GIFT_CONFIG,
      ...fromIdb,
      photos: fromIdb.photos && fromIdb.photos.length > 0 ? fromIdb.photos : DEFAULT_GIFT_CONFIG.photos,
    };
  }
  return loadGiftConfig();
}

/**
 * Safe saver: saves complete data to IndexedDB, and safely mirrors to localStorage
 * without ever throwing QuotaExceededError.
 */
export function saveGiftConfig(config: GiftStoryConfig): void {
  // 1. Asynchronously persist to IndexedDB (virtually unlimited quota)
  idbSaveConfig(config).catch(() => {});

  // 2. Try saving to localStorage
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch {
    // QuotaExceededError handled gracefully:
    // Strip large base64 data URLs from localStorage copy so that text settings
    // (names, letter, fireplace quote, captions) still persist in localStorage,
    // while the full photos remain safe in IndexedDB.
    try {
      const lightweightConfig: GiftStoryConfig = {
        ...config,
        photos: config.photos.map((p, i) => {
          if (p.url && p.url.startsWith('data:')) {
            // Keep default preset URL or lightweight stub in localStorage
            const defaultPhoto = DEFAULT_GIFT_CONFIG.photos[i];
            return {
              ...p,
              url: defaultPhoto ? defaultPhoto.url : '',
            };
          }
          return p;
        }),
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(lightweightConfig));
    } catch {
      // If even that fails (e.g. extremely constrained environment), silent fail
      // as IndexedDB already has the full state.
    }
  }
}

export function resetGiftConfig(): GiftStoryConfig {
  try {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem('cozy_christmas_gift_data_v1');
  } catch {}

  openDB()
    .then((db) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).delete(IDB_KEY);
    })
    .catch(() => {});

  return DEFAULT_GIFT_CONFIG;
}
