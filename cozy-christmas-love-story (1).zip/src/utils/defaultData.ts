import { GiftStoryConfig } from '../types';

export const COTTAGE_IMAGE = '/src/assets/images/cottage_storybook_soft_1794080537413.jpg';
export const FIREPLACE_IMAGE = '/src/assets/images/zoomed_in_burning_fire_1794080537793.jpg';

export const DEFAULT_GIFT_CONFIG: GiftStoryConfig = {
  recipientName: 'Nikki',
  senderName: 'Forever Yours',
  cottageQuestion: 'Would you like to go inside?',
  cottageButtonText: 'open the door',
  photos: [
    {
      id: 'photo-1',
      url: '/src/assets/images/couple_snow_laughing_1793776856447.jpg',
      caption: 'When it first started snowing and neither of us wanted to go back inside.',
      date: '',
      location: '',
    },
    {
      id: 'photo-2',
      url: '/src/assets/images/couple_cocoa_lights_1793776858078.jpg',
      caption: 'Sharing one cup of hot cocoa with too many marshmallows by the fairy lights.',
      date: 'Winter days',
      location: 'Our cozy corner',
    },
    {
      id: 'photo-3',
      url: '/src/assets/images/couple_holiday_walk_1793776857970.jpg',
      caption: 'Holding hands looking at all the holiday lights and dreaming together.',
      date: 'Holiday walk',
      location: 'Under the lights',
    },
  ],
  fireplaceQuote: 'for all the times we pretended and ate like we were living here',
  fireplaceSubtext: 'Eating takeout straight from the box, making late night pasta, and imagining a future together.',
  letterEnvelopeTitle: 'Merry Christmas',
  letterGreeting: 'My Dearest Love,',
  letterBody: `Merry Christmas, babe.

This year has been my favorite one yet, simply because I got to spend so much of it beside you. From the quiet mornings making coffee to our ridiculous late-night talks where we couldn't stop laughing, you have turned every ordinary moment into something I cherish with my whole heart.

I made this little cozy corner just for you as an early Christmas gift — a reminder of all the memories we've already built, the cozy dreams we share, and the many winters we still have ahead of us. 

Thank you for being my warmest shelter, my biggest cheerleader, and the safest place I know. No matter how cold it gets outside, being with you always feels like coming home to a warm fire.

I can't wait to spend Christmas morning wrapped in blankets with you.`,
  letterSignoff: 'With all my love, always and forever ♡',
  loveYouHeadline: 'I Love You',
  loveYouSubtext: '',
  reasonsWhy: [],
};
