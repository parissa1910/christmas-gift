import React, { useState } from 'react';
import { X, Save, RotateCcw, Upload, Plus, Trash2, Download, FileUp, Check } from 'lucide-react';
import { GiftStoryConfig, PhotoItem } from '../types';
import { resetGiftConfig } from '../utils/storage';

interface EditGiftModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: GiftStoryConfig;
  onSave: (updated: GiftStoryConfig) => void;
}

export const EditGiftModal: React.FC<EditGiftModalProps> = ({
  isOpen,
  onClose,
  config,
  onSave,
}) => {
  const [formData, setFormData] = useState<GiftStoryConfig>(config);
  const [activeTab, setActiveTab] = useState<'basics' | 'photos' | 'fireplace' | 'letter' | 'reasons'>('basics');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>, id: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setFormData((prev) => ({
        ...prev,
        photos: prev.photos.map((p) => (p.id === id ? { ...p, url: dataUrl } : p)),
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleAddPhoto = () => {
    const newPhoto: PhotoItem = {
      id: `photo-${Date.now()}`,
      url: '/src/assets/images/couple_holiday_walk_1793776857970.jpg',
      caption: 'Another memory of us',
      date: 'December',
      location: 'Together',
    };
    setFormData((prev) => ({
      ...prev,
      photos: [...prev.photos, newPhoto],
    }));
  };

  const handleRemovePhoto = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      photos: prev.photos.filter((p) => p.id !== id),
    }));
  };

  const handleAddReason = () => {
    setFormData((prev) => ({
      ...prev,
      reasonsWhy: [...prev.reasonsWhy, 'A special new reason why I love you'],
    }));
  };

  const handleRemoveReason = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      reasonsWhy: prev.reasonsWhy.filter((_, i) => i !== index),
    }));
  };

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(formData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', 'christmas-gift-config.json');
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    setStatusMsg('Gift configuration exported successfully!');
    setTimeout(() => setStatusMsg(null), 3000);
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        setFormData(parsed);
        setStatusMsg('Config imported successfully!');
        setTimeout(() => setStatusMsg(null), 3000);
      } catch (err) {
        alert('Invalid JSON file format.');
      }
    };
    reader.readAsText(file);
  };

  const handleReset = () => {
    if (confirm('Reset all photos, captions, and letters back to original presets?')) {
      const reset = resetGiftConfig();
      setFormData(reset);
      onSave(reset);
      setStatusMsg('Reset to default presets.');
      setTimeout(() => setStatusMsg(null), 3000);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/80">
          <div>
            <h3 className="text-lg font-serif-title font-bold text-amber-200">
              Personalize Your Christmas Gift
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Customize photos of you two, edit the heartfelt letter, and fine-tune your messages.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status Notification */}
        {statusMsg && (
          <div className="bg-emerald-950/90 text-emerald-300 text-xs px-6 py-2 border-b border-emerald-500/30 flex items-center gap-2">
            <Check className="w-3.5 h-3.5" />
            <span>{statusMsg}</span>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 py-2 border-b border-white/10 bg-slate-950/40 overflow-x-auto text-xs">
          {[
            { id: 'basics', label: 'Names & Intro' },
            { id: 'photos', label: `Mantle Photos (${formData.photos.length})` },
            { id: 'fireplace', label: 'Fireplace Note' },
            { id: 'letter', label: 'Personal Letter' },
            { id: 'reasons', label: `Reasons (${formData.reasonsWhy.length})` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors cursor-pointer font-medium ${
                activeTab === tab.id
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5 text-left text-xs">
          {activeTab === 'basics' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Boyfriend's Name / Nickname
                  </label>
                  <input
                    type="text"
                    value={formData.recipientName}
                    onChange={(e) => setFormData({ ...formData, recipientName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 text-white border border-white/10 rounded-lg focus:border-amber-400 focus:outline-none text-sm"
                    placeholder="e.g. Alex, Babe, My Love"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Your Name / Sign-off Signature
                  </label>
                  <input
                    type="text"
                    value={formData.senderName}
                    onChange={(e) => setFormData({ ...formData, senderName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 text-white border border-white/10 rounded-lg focus:border-amber-400 focus:outline-none text-sm"
                    placeholder="e.g. Maya, Forever Yours"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Cottage Door Prompt Question
                </label>
                <input
                  type="text"
                  value={formData.cottageQuestion}
                  onChange={(e) => setFormData({ ...formData, cottageQuestion: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 text-white border border-white/10 rounded-lg focus:border-amber-400 focus:outline-none text-sm"
                  placeholder="Would you like to go inside?"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Cottage Door Button Text
                </label>
                <input
                  type="text"
                  value={formData.cottageButtonText}
                  onChange={(e) => setFormData({ ...formData, cottageButtonText: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 text-white border border-white/10 rounded-lg focus:border-amber-400 focus:outline-none text-sm"
                  placeholder="Open the Door & Step Inside"
                />
              </div>
            </div>
          )}

          {activeTab === 'photos' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-slate-300 font-medium">
                  Mantle Photos (displayed on the holiday hearth)
                </span>
                <button
                  type="button"
                  onClick={handleAddPhoto}
                  className="flex items-center gap-1 px-3 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded-lg transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Picture Frame</span>
                </button>
              </div>

              <div className="space-y-4">
                {formData.photos.map((photo, idx) => (
                  <div
                    key={photo.id}
                    className="p-4 bg-slate-950/60 border border-white/10 rounded-xl flex flex-col sm:flex-row gap-4 items-start"
                  >
                    {/* Thumbnail preview */}
                    <div className="relative w-28 aspect-[4/3] rounded-lg overflow-hidden bg-slate-800 border-2 border-amber-500/40 shrink-0">
                      <img
                        src={photo.url}
                        alt={photo.caption}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <label className="absolute inset-0 bg-black/50 opacity-0 hover:opacity-100 flex items-center justify-center text-white cursor-pointer transition-opacity">
                        <Upload className="w-4 h-4" />
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => handlePhotoUpload(e, photo.id)}
                        />
                      </label>
                    </div>

                    {/* Inputs */}
                    <div className="flex-1 w-full space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-amber-400 font-semibold">Frame #{idx + 1}</span>
                        {formData.photos.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemovePhoto(photo.id)}
                            className="text-red-400 hover:text-red-300 p-1"
                            title="Remove Photo"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      <input
                        type="text"
                        value={photo.caption}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            photos: formData.photos.map((p) =>
                              p.id === photo.id ? { ...p, caption: e.target.value } : p
                            ),
                          })
                        }
                        className="w-full px-2.5 py-1.5 bg-slate-900 border border-white/10 rounded text-white text-xs focus:border-amber-400 focus:outline-none"
                        placeholder="Memory caption..."
                      />

                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={photo.location || ''}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              photos: formData.photos.map((p) =>
                                p.id === photo.id ? { ...p, location: e.target.value } : p
                              ),
                            })
                          }
                          className="w-full px-2.5 py-1 bg-slate-900 border border-white/10 rounded text-slate-300 text-xs focus:border-amber-400 focus:outline-none"
                          placeholder="Place / Memory note"
                        />
                        <input
                          type="text"
                          value={photo.date || ''}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              photos: formData.photos.map((p) =>
                                p.id === photo.id ? { ...p, date: e.target.value } : p
                              ),
                            })
                          }
                          className="w-full px-2.5 py-1 bg-slate-900 border border-white/10 rounded text-slate-300 text-xs focus:border-amber-400 focus:outline-none"
                          placeholder="Date (e.g. December)"
                        />
                      </div>

                      <div className="flex items-center gap-2 pt-1">
                        <label className="text-[11px] text-amber-300 hover:underline cursor-pointer flex items-center gap-1">
                          <Upload className="w-3 h-3" />
                          <span>Upload photo from your computer/phone</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => handlePhotoUpload(e, photo.id)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'fireplace' && (
            <div className="space-y-4">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Fireplace Quote (written under the mantle)
                </label>
                <textarea
                  rows={2}
                  value={formData.fireplaceQuote}
                  onChange={(e) => setFormData({ ...formData, fireplaceQuote: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 text-amber-200 font-serif-title border border-white/10 rounded-lg focus:border-amber-400 focus:outline-none text-sm"
                  placeholder="for all the times we pretended and ate like we were living here"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Sweet Fireplace Subtext
                </label>
                <textarea
                  rows={3}
                  value={formData.fireplaceSubtext}
                  onChange={(e) => setFormData({ ...formData, fireplaceSubtext: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 text-white border border-white/10 rounded-lg focus:border-amber-400 focus:outline-none text-xs"
                  placeholder="Additional heartwarming memory..."
                />
              </div>
            </div>
          )}

          {activeTab === 'letter' && (
            <div className="space-y-4">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Envelope Title
                </label>
                <input
                  type="text"
                  value={formData.letterEnvelopeTitle}
                  onChange={(e) => setFormData({ ...formData, letterEnvelopeTitle: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 text-white border border-white/10 rounded-lg focus:border-amber-400 focus:outline-none text-sm font-serif-title"
                  placeholder="Merry Christmas"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Letter Greeting
                </label>
                <input
                  type="text"
                  value={formData.letterGreeting}
                  onChange={(e) => setFormData({ ...formData, letterGreeting: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 text-white border border-white/10 rounded-lg focus:border-amber-400 focus:outline-none text-sm font-serif-title"
                  placeholder="My Dearest Love,"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Your Christmas Letter Message
                </label>
                <textarea
                  rows={9}
                  value={formData.letterBody}
                  onChange={(e) => setFormData({ ...formData, letterBody: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 text-slate-100 border border-white/10 rounded-lg focus:border-amber-400 focus:outline-none text-xs leading-relaxed font-sans"
                  placeholder="Write your personal letter..."
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Letter Sign-off
                </label>
                <input
                  type="text"
                  value={formData.letterSignoff}
                  onChange={(e) => setFormData({ ...formData, letterSignoff: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 text-white border border-white/10 rounded-lg focus:border-amber-400 focus:outline-none text-sm"
                  placeholder="With all my love, always and forever ♡"
                />
              </div>
            </div>
          )}

          {activeTab === 'reasons' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-slate-300 font-medium">
                  Little Reasons Why I Love You (Gift Tags)
                </span>
                <button
                  type="button"
                  onClick={handleAddReason}
                  className="flex items-center gap-1 px-3 py-1 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 rounded-lg transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Reason</span>
                </button>
              </div>

              <div className="space-y-2">
                {formData.reasonsWhy.map((reason, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="text-rose-400 font-bold w-6 text-center">#{idx + 1}</span>
                    <input
                      type="text"
                      value={reason}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          reasonsWhy: formData.reasonsWhy.map((r, i) => (i === idx ? e.target.value : r)),
                        })
                      }
                      className="flex-1 px-3 py-1.5 bg-slate-950 text-white border border-white/10 rounded-lg focus:border-rose-400 focus:outline-none text-xs"
                      placeholder="Reason why you love him..."
                    />
                    <button
                      type="button"
                      onClick={() => handleRemoveReason(idx)}
                      className="p-1.5 text-slate-400 hover:text-red-400 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Backup / Export / Reset Bar */}
          <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleExportJson}
                className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
                title="Download your custom data as a JSON backup"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Backup</span>
              </button>

              <span className="text-white/20">|</span>

              <label className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors cursor-pointer">
                <FileUp className="w-3.5 h-3.5" />
                <span>Import Backup</span>
                <input
                  type="file"
                  accept="application/json"
                  className="hidden"
                  onChange={handleImportJson}
                />
              </label>
            </div>

            <button
              type="button"
              onClick={handleReset}
              className="text-red-400/80 hover:text-red-300 transition-colors cursor-pointer flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Defaults</span>
            </button>
          </div>
        </form>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-t border-white/10">
          <span className="text-[11px] text-slate-400 font-light">
            Changes auto-save to this browser and will be visible in the gift story.
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs text-slate-300 hover:text-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              className="flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg shadow-md cursor-pointer transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save & Update Gift</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
