import React, { useState } from 'react';
import { Volume2, VolumeX, Music, Settings, Sparkles, Github } from 'lucide-react';
import { SceneId } from '../types';
import { audioEngine } from '../utils/audioEngine';

interface TopNavProps {
  currentScene: SceneId;
  onSelectScene: (scene: SceneId) => void;
  onOpenEditModal: () => void;
  onOpenGithubModal: () => void;
  isCustomizing: boolean;
  onToggleCustomizing: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentScene,
  onSelectScene,
  onOpenEditModal,
  onOpenGithubModal,
  isCustomizing,
  onToggleCustomizing,
}) => {
  const [isMusicPlaying, setIsMusicPlaying] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  const handleToggleMusic = () => {
    const active = audioEngine.toggleMusic();
    setIsMusicPlaying(active);
  };

  const handleToggleMute = () => {
    const muted = audioEngine.toggleMute();
    setIsMuted(muted);
  };

  const scenes: { id: SceneId; label: string }[] = [
    { id: 'cottage', label: 'Cottage' },
    { id: 'mantle', label: 'Mantle' },
    { id: 'fireplace', label: 'Fireplace' },
    { id: 'letter', label: 'Letter' },
    { id: 'loveyou', label: 'I Love You' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-slate-950/75 backdrop-blur-md border-b border-white/10 px-4 md:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Single text wordmark */}
        <button
          onClick={() => onSelectScene('cottage')}
          className="text-lg md:text-xl font-serif-title tracking-tight text-amber-100 hover:text-amber-300 transition-colors whitespace-nowrap shrink-0 flex items-center gap-2 group text-left cursor-pointer"
        >
          <span className="text-red-400 group-hover:scale-110 transition-transform">🎄</span>
          <span className="font-semibold">A Cozy Christmas</span>
        </button>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-300">
          {scenes.map((s) => {
            const isActive = currentScene === s.id;
            return (
              <button
                key={s.id}
                onClick={() => onSelectScene(s.id)}
                className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer text-xs md:text-sm tracking-wide ${
                  isActive
                    ? 'text-amber-300 font-semibold border-b-2 border-amber-400 pb-0.5'
                    : 'hover:text-amber-100 text-slate-300'
                }`}
              >
                {s.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Action & Controls */}
        <div className="flex items-center gap-2 md:gap-3 shrink-0">
          {/* Music Toggle */}
          <button
            onClick={handleToggleMusic}
            title={isMusicPlaying ? 'Pause Christmas Music' : 'Play Christmas Music Box'}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              isMusicPlaying
                ? 'bg-emerald-950/90 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-900/30'
                : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
            }`}
          >
            <Music className={`w-3.5 h-3.5 ${isMusicPlaying ? 'animate-bounce text-emerald-400' : ''}`} />
            <span className="hidden sm:inline">{isMusicPlaying ? 'Music Playing' : 'Play Music'}</span>
          </button>

          {/* Mute Toggle */}
          <button
            onClick={handleToggleMute}
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 transition-colors cursor-pointer"
            aria-label="Toggle Mute"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>

          {/* Personalize / Edit Button */}
          <button
            onClick={onOpenEditModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-amber-200 bg-amber-950/60 hover:bg-amber-900/80 border border-amber-500/40 rounded-lg transition-colors cursor-pointer shadow-sm"
            title="Edit photos, letter, and message"
          >
            <Settings className="w-3.5 h-3.5 text-amber-400" />
            <span className="whitespace-nowrap">Edit Gift</span>
          </button>

          {/* GitHub Guide Button */}
          <button
            onClick={onOpenGithubModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg transition-colors cursor-pointer"
            title="How to deploy this to GitHub Pages"
          >
            <Github className="w-3.5 h-3.5 text-slate-300" />
            <span className="hidden md:inline whitespace-nowrap">Deploy</span>
          </button>
        </div>
      </div>
    </header>
  );
};
