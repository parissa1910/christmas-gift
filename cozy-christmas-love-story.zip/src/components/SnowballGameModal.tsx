import React, { useState, useRef, useEffect } from 'react';
import { X, Sparkles, RotateCcw, Volume2, ArrowRight } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';

interface FlyingSnowball {
  id: number;
  startX: number;
  startY: number;
  targetX: number;
  targetY: number;
  progress: number; // 0 to 1
  scale: number;
  hitTarget?: 'snowman' | 'tree' | 'present' | 'ground';
}

interface SplatEffect {
  id: number;
  x: number;
  y: number;
  size: number;
  type: string;
}

interface FloatingText {
  id: number;
  text: string;
  x: number;
  y: number;
}

export const SnowballGameModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onGoInside: () => void;
}> = ({ isOpen, onClose, onGoInside }) => {
  const [score, setScore] = useState<number>(0);
  const [hits, setHits] = useState<number>(0);
  const [snowmanMood, setSnowmanMood] = useState<'happy' | 'hit' | 'wobble'>('happy');
  const [snowmanComment, setSnowmanComment] = useState<string>('Throw a snowball at me!');
  const [flyingSnowballs, setFlyingSnowballs] = useState<FlyingSnowball[]>([]);
  const [splats, setSplats] = useState<SplatEffect[]>([]);
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);
  const [isTreeWobbling, setIsTreeWobbling] = useState<boolean>(false);
  const arenaRef = useRef<HTMLDivElement | null>(null);

  // Animation loop for flying snowballs
  useEffect(() => {
    if (!isOpen) return;

    let animId: number;
    const update = () => {
      setFlyingSnowballs((prev) => {
        if (prev.length === 0) return prev;
        const remaining: FlyingSnowball[] = [];

        prev.forEach((ball) => {
          const nextProgress = ball.progress + 0.045;
          if (nextProgress >= 1) {
            // Hit!
            handleSnowballImpact(ball);
          } else {
            remaining.push({
              ...ball,
              progress: nextProgress,
              scale: 1 - nextProgress * 0.45, // Shrinks as it travels into background
            });
          }
        });

        return remaining;
      });

      animId = requestAnimationFrame(update);
    };

    animId = requestAnimationFrame(update);
    return () => cancelAnimationFrame(animId);
  }, [isOpen]);

  const handleSnowballImpact = (ball: FlyingSnowball) => {
    audioEngine.playSnowballHit();

    // Add splat effect
    const newSplat: SplatEffect = {
      id: Date.now() + Math.random(),
      x: ball.targetX,
      y: ball.targetY,
      size: Math.random() * 15 + 28,
      type: ball.hitTarget || 'ground',
    };

    setSplats((prev) => [...prev.slice(-12), newSplat]);

    // Check hit target
    if (ball.hitTarget === 'snowman') {
      setScore((s) => s + 25);
      setHits((h) => h + 1);
      setSnowmanMood('hit');
      const lines = [
        'Brrr! Direct hit! ❄️',
        'Hey! Right on the nose! 🥕',
        'Brilliant throw, nice aim! 🎯',
        'Cold cold cold! Haha! ⛄',
        'You got me! Love it! 🤍',
      ];
      setSnowmanComment(lines[Math.floor(Math.random() * lines.length)]);

      // Spawn floating score
      addFloatingText('+25 🎯', ball.targetX, ball.targetY - 20);

      setTimeout(() => setSnowmanMood('happy'), 800);
    } else if (ball.hitTarget === 'tree') {
      setScore((s) => s + 15);
      setHits((h) => h + 1);
      setIsTreeWobbling(true);
      addFloatingText('+15 🎄', ball.targetX, ball.targetY - 20);
      setTimeout(() => setIsTreeWobbling(false), 700);
    } else {
      addFloatingText('Poof! ❄️', ball.targetX, ball.targetY - 10);
    }
  };

  const addFloatingText = (text: string, x: number, y: number) => {
    const id = Date.now() + Math.random();
    setFloatingTexts((prev) => [...prev, { id, text, x, y }]);
    setTimeout(() => {
      setFloatingTexts((prev) => prev.filter((item) => item.id !== id));
    }, 1200);
  };

  const handleArenaClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!arenaRef.current) return;
    const rect = arenaRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    // Check if target is snowman (approx bounds in percentage/pixels)
    // Snowman center is around ~38% X, 55% Y
    const snowmanX = rect.width * 0.38;
    const snowmanY = rect.height * 0.58;
    const distToSnowman = Math.hypot(clickX - snowmanX, clickY - snowmanY);

    // Tree center is around ~72% X, 50% Y
    const treeX = rect.width * 0.72;
    const treeY = rect.height * 0.52;
    const distToTree = Math.hypot(clickX - treeX, clickY - treeY);

    let hitTarget: 'snowman' | 'tree' | 'ground' = 'ground';
    if (distToSnowman < 75) {
      hitTarget = 'snowman';
    } else if (distToTree < 90) {
      hitTarget = 'tree';
    }

    // Play throw whoosh
    audioEngine.playSnowballThrow();

    // Launch snowball from bottom center
    const startX = rect.width * 0.5;
    const startY = rect.height * 0.95;

    const newBall: FlyingSnowball = {
      id: Date.now() + Math.random(),
      startX,
      startY,
      targetX: clickX,
      targetY: clickY,
      progress: 0,
      scale: 1,
      hitTarget,
    };

    setFlyingSnowballs((prev) => [...prev, newBall]);
  };

  const resetGame = () => {
    setScore(0);
    setHits(0);
    setSplats([]);
    setSnowmanComment('Throw a snowball at me!');
    setSnowmanMood('happy');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-white/20 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-white/10 bg-slate-950/60">
          <div className="flex items-center gap-2">
            <span className="text-xl">⛄</span>
            <h3 className="text-base md:text-lg font-serif-title font-semibold text-amber-100">
              Cottage Yard Snowball Fight
            </h3>
          </div>

          {/* Stats Bar */}
          <div className="flex items-center gap-4 text-xs font-medium text-slate-300">
            <div className="flex items-center gap-1.5 bg-amber-950/40 px-3 py-1 rounded-full border border-amber-500/20">
              <span className="text-amber-400">Cheer:</span>
              <span className="font-bold text-amber-200 tabular-nums">{score}</span>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 bg-white/5 px-3 py-1 rounded-full border border-white/10">
              <span className="text-slate-400">Hits:</span>
              <span className="font-bold text-white tabular-nums">{hits}</span>
            </div>
            <button
              onClick={resetGame}
              title="Reset Game"
              className="p-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Snowball Arena Canvas / Field */}
        <div
          ref={arenaRef}
          onClick={handleArenaClick}
          className="relative w-full h-[400px] md:h-[480px] bg-gradient-to-b from-slate-950 via-indigo-950 to-slate-900 overflow-hidden cursor-crosshair select-none"
        >
          {/* Distant snowy pines */}
          <div className="absolute inset-x-0 bottom-12 h-36 opacity-30 flex justify-around pointer-events-none">
            <div className="w-16 h-32 bg-emerald-900 rounded-t-full"></div>
            <div className="w-20 h-40 bg-emerald-950 rounded-t-full"></div>
            <div className="w-16 h-28 bg-emerald-900 rounded-t-full"></div>
            <div className="w-24 h-44 bg-emerald-950 rounded-t-full"></div>
          </div>

          {/* Snowy ground base */}
          <div className="absolute inset-x-0 bottom-0 h-36 bg-gradient-to-t from-slate-100 via-sky-100 to-sky-200/90 rounded-t-[50%] scale-x-125 border-t border-sky-300 pointer-events-none shadow-inner"></div>

          {/* Target 1: Animated Snowman */}
          <div
            className={`absolute left-[34%] sm:left-[38%] bottom-20 -translate-x-1/2 flex flex-col items-center pointer-events-none transition-transform duration-300 ${
              snowmanMood === 'hit' ? 'scale-95 rotate-6' : 'animate-sway'
            }`}
          >
            {/* Snowman speech bubble */}
            <div className="mb-2 px-3 py-1 bg-white/95 text-slate-900 text-xs font-semibold rounded-full shadow-lg border border-slate-200 whitespace-nowrap animate-float-slow">
              {snowmanComment}
            </div>

            {/* Top Hat */}
            <div className="relative flex flex-col items-center">
              <div className="w-12 h-10 bg-slate-900 rounded-t-md border-b-4 border-red-600 shadow-md"></div>
              <div className="w-18 h-2.5 bg-slate-900 rounded-full shadow-sm -mt-0.5"></div>
            </div>

            {/* Head */}
            <div className="relative w-16 h-16 bg-gradient-to-b from-white to-slate-200 rounded-full shadow-inner border border-sky-200 flex items-center justify-center -mt-2">
              {/* Coal Eyes */}
              <div className="absolute top-4 left-4 w-2 h-2 bg-slate-900 rounded-full"></div>
              <div className="absolute top-4 right-4 w-2 h-2 bg-slate-900 rounded-full"></div>
              {/* Carrot Nose */}
              <div className="absolute top-6.5 w-6 h-2.5 bg-gradient-to-r from-amber-600 to-orange-500 rounded-r-full shadow-sm transform rotate-6"></div>
              {/* Coal Smile */}
              <div className="absolute bottom-3 flex gap-1">
                <div className="w-1 h-1 bg-slate-800 rounded-full"></div>
                <div className="w-1 h-1 bg-slate-800 rounded-full mt-0.5"></div>
                <div className="w-1 h-1 bg-slate-800 rounded-full mt-0.5"></div>
                <div className="w-1 h-1 bg-slate-800 rounded-full"></div>
              </div>
            </div>

            {/* Cozy Scarf */}
            <div className="w-20 h-4 bg-red-600 rounded-full shadow-sm -mt-1.5 z-10 flex justify-end">
              <div className="w-4 h-9 bg-red-600 rounded-b-md shadow-md mr-2"></div>
            </div>

            {/* Torso */}
            <div className="relative w-24 h-24 bg-gradient-to-b from-white to-slate-200 rounded-full shadow-inner border border-sky-200 flex flex-col items-center justify-center -mt-2">
              <div className="w-2.5 h-2.5 bg-slate-900 rounded-full mb-2"></div>
              <div className="w-2.5 h-2.5 bg-slate-900 rounded-full"></div>

              {/* Twig Arms */}
              <div className="absolute -left-7 top-6 w-8 h-1.5 bg-amber-900 transform -rotate-25 rounded-full"></div>
              <div className="absolute -right-7 top-6 w-8 h-1.5 bg-amber-900 transform rotate-25 rounded-full"></div>
            </div>

            {/* Bottom Ball */}
            <div className="w-32 h-32 bg-gradient-to-b from-white to-slate-300 rounded-full shadow-lg border border-sky-200 -mt-3"></div>
          </div>

          {/* Target 2: Decorated Christmas Tree */}
          <div
            className={`absolute right-[16%] sm:right-[22%] bottom-20 flex flex-col items-center pointer-events-none transition-transform duration-200 ${
              isTreeWobbling ? 'scale-105 -rotate-3' : ''
            }`}
          >
            {/* Star */}
            <div className="text-2xl text-amber-300 animate-spin-slow">⭐</div>
            {/* Tier 1 */}
            <div className="w-20 h-16 bg-emerald-800 rounded-t-full relative -mt-2 flex justify-center items-center">
              <div className="w-2.5 h-2.5 bg-red-500 rounded-full absolute top-6 left-3 animate-pulse"></div>
              <div className="w-2.5 h-2.5 bg-amber-400 rounded-full absolute top-7 right-4 animate-pulse"></div>
            </div>
            {/* Tier 2 */}
            <div className="w-32 h-20 bg-emerald-700 rounded-t-full relative -mt-6 flex justify-center items-center">
              <div className="w-3 h-3 bg-blue-400 rounded-full absolute top-8 left-5 animate-pulse"></div>
              <div className="w-3 h-3 bg-red-500 rounded-full absolute top-6 right-6 animate-pulse"></div>
              <div className="w-3 h-3 bg-amber-300 rounded-full absolute top-9 left-14 animate-pulse"></div>
            </div>
            {/* Tier 3 */}
            <div className="w-44 h-24 bg-emerald-600 rounded-t-full relative -mt-8 flex justify-center items-center">
              <div className="w-3.5 h-3.5 bg-yellow-300 rounded-full absolute top-9 left-7"></div>
              <div className="w-3.5 h-3.5 bg-red-500 rounded-full absolute top-10 right-9"></div>
              <div className="w-3.5 h-3.5 bg-indigo-300 rounded-full absolute top-12 left-20"></div>
            </div>
            {/* Trunk */}
            <div className="w-8 h-8 bg-amber-950 rounded-b-md -mt-1"></div>
            {/* Wrapped gifts at tree base */}
            <div className="flex gap-2 -mt-2">
              <div className="w-7 h-7 bg-red-600 rounded-sm border-t-2 border-amber-300 shadow"></div>
              <div className="w-8 h-8 bg-emerald-600 rounded-sm border-t-2 border-red-300 shadow"></div>
            </div>
          </div>

          {/* Splats on field / targets */}
          {splats.map((splat) => (
            <div
              key={splat.id}
              className="absolute pointer-events-none transform -translate-x-1/2 -translate-y-1/2 animate-scale-up"
              style={{ left: splat.x, top: splat.y }}
            >
              <div
                className="bg-white/95 rounded-full shadow-md border border-sky-100 flex items-center justify-center"
                style={{ width: splat.size, height: splat.size }}
              >
                <div className="w-1/2 h-1/2 bg-sky-100 rounded-full opacity-60"></div>
              </div>
            </div>
          ))}

          {/* Flying Snowballs */}
          {flyingSnowballs.map((ball) => {
            const currentX = ball.startX + (ball.targetX - ball.startX) * ball.progress;
            // Parabolic arc for realistic throwing curve
            const arcHeight = 120 * Math.sin(ball.progress * Math.PI);
            const currentY = ball.startY + (ball.targetY - ball.startY) * ball.progress - arcHeight;

            return (
              <div
                key={ball.id}
                className="absolute pointer-events-none transform -translate-x-1/2 -translate-y-1/2 z-30"
                style={{
                  left: currentX,
                  top: currentY,
                  transform: `translate(-50%, -50%) scale(${ball.scale})`,
                }}
              >
                {/* Snowball sphere with soft gradient */}
                <div className="w-9 h-9 bg-gradient-to-tr from-sky-200 via-white to-white rounded-full shadow-lg border border-sky-100 flex items-center justify-center">
                  <div className="w-3 h-3 bg-white rounded-full opacity-90 -mt-1 -ml-1"></div>
                </div>
              </div>
            );
          })}

          {/* Floating score text */}
          {floatingTexts.map((ft) => (
            <div
              key={ft.id}
              className="absolute pointer-events-none transform -translate-x-1/2 -translate-y-1/2 text-sm font-bold text-amber-300 drop-shadow-md z-40 transition-all duration-700 animate-fade-out"
              style={{ left: ft.x, top: ft.y }}
            >
              {ft.text}
            </div>
          ))}

          {/* Aim instruction crosshair prompt */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-slate-950/70 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/10 text-xs text-slate-200 flex items-center gap-2 pointer-events-none shadow-lg">
            <span>🎯</span>
            <span>Click anywhere to fling snowballs at the Snowman or Tree!</span>
          </div>

          {/* Thrower hands / snowball ready at bottom */}
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 pointer-events-none flex flex-col items-center">
            <div className="w-12 h-12 bg-white rounded-full shadow-2xl border-2 border-sky-100 flex items-center justify-center animate-bounce">
              <span className="text-xl">❄️</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-6 py-4 bg-slate-950/80 border-t border-white/10">
          <p className="text-xs text-slate-400">
            Having fun playing in the snow? When you're cold, warm up by the fire inside.
          </p>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-colors cursor-pointer"
            >
              Back to Yard
            </button>
            <button
              onClick={() => {
                onClose();
                onGoInside();
              }}
              className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 rounded-lg shadow-md shadow-red-900/40 transition-all cursor-pointer"
            >
              <span>Step Inside Cottage</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
