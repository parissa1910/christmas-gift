import React, { useEffect, useState } from 'react';
import { Flame, ArrowRight, Edit3, Heart, Coffee } from 'lucide-react';
import { FIREPLACE_IMAGE } from '../utils/defaultData';
import { audioEngine } from '../utils/audioEngine';

interface SceneFireplaceProps {
  quote: string;
  subtext: string;
  onUpdateQuote: (quote: string, subtext: string) => void;
  onOpenLetter: () => void;
}

export const SceneFireplace: React.FC<SceneFireplaceProps> = ({
  quote,
  subtext,
  onUpdateQuote,
  onOpenLetter,
}) => {
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [quoteDraft, setQuoteDraft] = useState<string>(quote);
  const [subtextDraft, setSubtextDraft] = useState<string>(subtext);

  useEffect(() => {
    audioEngine.startFireCrackle();
    return () => {
      audioEngine.stopFireCrackle();
    };
  }, []);

  const handleSave = () => {
    onUpdateQuote(quoteDraft, subtextDraft);
    setIsEditing(false);
  };

  return (
    <div className="relative w-full min-h-[calc(100vh-64px)] flex flex-col items-center justify-between py-10 px-4 sm:px-6 overflow-hidden">
      {/* Background Image of the Fireplace */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-transform duration-1000"
        style={{
          backgroundImage: `url(${FIREPLACE_IMAGE})`,
        }}
      >
        {/* Warm Vignette Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-slate-950/80" />
      </div>

      {/* Floating Embers / Fire Sparkles */}
      <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden">
        {Array.from({ length: 18 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-amber-400 opacity-70 animate-float-slow"
            style={{
              width: `${Math.random() * 4 + 2}px`,
              height: `${Math.random() * 4 + 2}px`,
              bottom: `${Math.random() * 40 + 20}%`,
              left: `${Math.random() * 60 + 20}%`,
              animationDuration: `${Math.random() * 3 + 2}s`,
              filter: 'blur(0.5px)',
            }}
          />
        ))}
      </div>

      {/* Top Tag */}
      <div className="relative z-20 text-center">
        <span className="text-xs uppercase tracking-widest text-amber-300/80 font-medium bg-slate-950/60 backdrop-blur-sm px-4 py-1 rounded-full border border-amber-500/20">
          Chapter 2 · Beside the Hearth
        </span>
      </div>

      {/* Central Emotion Card: The Fireplace Quote */}
      <div className="relative z-20 max-w-2xl w-full flex flex-col items-center text-center my-auto px-4">
        {/* Hot Cocoa & Flame Icon */}
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 rounded-full bg-amber-950/70 border border-amber-500/40 text-amber-300 shadow-lg shadow-amber-500/20 animate-pulse">
            <Flame className="w-6 h-6 text-orange-400" />
          </div>
          <div className="p-2.5 rounded-full bg-red-950/60 border border-red-500/30 text-rose-300 shadow">
            <Coffee className="w-5 h-5 text-amber-200" />
          </div>
        </div>

        {!isEditing ? (
          <div className="bg-slate-950/80 border border-amber-500/30 backdrop-blur-md p-6 sm:p-10 rounded-3xl shadow-2xl relative group">
            {/* The Core Quote Requested by User */}
            <h2 className="text-2xl sm:text-4xl md:text-5xl font-serif-title font-bold text-amber-100 leading-tight drop-shadow-md">
              "{quote}"
            </h2>

            {subtext && (
              <p className="text-sm sm:text-base text-amber-200/80 font-light mt-4 leading-relaxed max-w-xl mx-auto">
                {subtext}
              </p>
            )}

            {/* Quick Edit Button */}
            <button
              onClick={() => {
                setQuoteDraft(quote);
                setSubtextDraft(subtext);
                setIsEditing(true);
              }}
              className="absolute top-4 right-4 p-2 text-amber-400/60 hover:text-amber-200 bg-amber-950/40 border border-amber-500/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
              title="Edit Fireplace Message"
            >
              <Edit3 className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="bg-slate-950/90 border border-amber-500/40 backdrop-blur-lg p-6 sm:p-8 rounded-3xl shadow-2xl w-full flex flex-col gap-3 text-left">
            <label className="text-xs font-semibold text-amber-300 uppercase tracking-wider">
              Edit Fireplace Quote
            </label>
            <textarea
              rows={2}
              value={quoteDraft}
              onChange={(e) => setQuoteDraft(e.target.value)}
              className="w-full px-3 py-2 bg-slate-900 text-white rounded-lg border border-amber-500/40 text-base font-serif-title focus:outline-none focus:border-amber-400"
              placeholder="Enter your special quote..."
            />
            <label className="text-xs font-semibold text-amber-300 uppercase tracking-wider mt-1">
              Sweet Subtext / Memory
            </label>
            <textarea
              rows={2}
              value={subtextDraft}
              onChange={(e) => setSubtextDraft(e.target.value)}
              className="w-full px-3 py-2 bg-slate-900 text-slate-200 rounded-lg border border-amber-500/40 text-xs focus:outline-none focus:border-amber-400"
              placeholder="Add more details about your memories..."
            />
            <div className="flex justify-end gap-2 mt-2">
              <button
                onClick={() => setIsEditing(false)}
                className="px-4 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-1.5 text-xs font-semibold bg-amber-600 hover:bg-amber-500 text-slate-950 rounded-md"
              >
                Save
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Move to Letter Button */}
      <div className="relative z-20 flex flex-col items-center mt-6">
        <button
          onClick={onOpenLetter}
          className="group flex items-center gap-2.5 px-8 py-3.5 rounded-full bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-semibold text-sm sm:text-base shadow-xl shadow-red-950/80 border border-rose-400/40 transition-all hover:scale-105 cursor-pointer"
        >
          <span>Open Your Christmas Letter</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
        <span className="text-[11px] text-amber-300/60 mt-1.5 font-light">
          A sealed envelope is waiting for you on the wooden table ✉️
        </span>
      </div>
    </div>
  );
};
