import React, { useState } from 'react';
import { Mail, ArrowRight, Edit3, Check, Heart, Sparkles, RefreshCw } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';

interface SceneLetterProps {
  envelopeTitle: string;
  greeting: string;
  body: string;
  signoff: string;
  onUpdateLetter: (greeting: string, body: string, signoff: string) => void;
  onNextSlide: () => void;
}

export const SceneLetter: React.FC<SceneLetterProps> = ({
  envelopeTitle,
  greeting,
  body,
  signoff,
  onUpdateLetter,
  onNextSlide,
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [greetingDraft, setGreetingDraft] = useState<string>(greeting);
  const [bodyDraft, setBodyDraft] = useState<string>(body);
  const [signoffDraft, setSignoffDraft] = useState<string>(signoff);

  const handleOpenLetter = () => {
    setIsOpen(true);
    audioEngine.playLetterOpenSound();
  };

  const handleSave = () => {
    onUpdateLetter(greetingDraft, bodyDraft, signoffDraft);
    setIsEditing(false);
  };

  const handleStartEdit = () => {
    setGreetingDraft(greeting);
    setBodyDraft(body);
    setSignoffDraft(signoff);
    setIsEditing(true);
  };

  return (
    <div className="relative w-full min-h-[calc(100vh-64px)] flex flex-col items-center justify-between py-10 px-4 sm:px-6 bg-[#0f141d] overflow-hidden">
      {/* Warm holiday tabletop background */}
      <div className="absolute inset-0 bg-radial from-[#1e151b] via-[#111622] to-[#090d15] pointer-events-none" />

      {/* Decorative pine needles & dried oranges in corners */}
      <div className="absolute top-4 left-4 text-3xl opacity-30 pointer-events-none select-none">
        🌿 🍊
      </div>
      <div className="absolute top-4 right-4 text-3xl opacity-30 pointer-events-none select-none">
        🔔 🌿
      </div>

      {/* Chapter Tag */}
      <div className="relative z-20 text-center">
        <span className="text-xs uppercase tracking-widest text-amber-300/80 font-medium bg-slate-900/60 backdrop-blur-sm px-4 py-1 rounded-full border border-amber-500/20">
          Chapter 3 · The Christmas Letter
        </span>
      </div>

      {/* Main Interactive Stage */}
      <div className="relative z-20 w-full max-w-2xl flex-1 flex flex-col items-center justify-center my-4">
        {!isOpen ? (
          /* Sealed Envelope View */
          <div
            onClick={handleOpenLetter}
            className="group relative w-full max-w-md sm:max-w-lg aspect-[16/11] bg-gradient-to-br from-[#7f1d1d] via-[#991b1b] to-[#6b1414] rounded-2xl shadow-2xl border-2 border-amber-500/40 p-6 flex flex-col items-center justify-between cursor-pointer transition-all duration-300 hover:scale-103 hover:shadow-red-950/80 animate-fade-in"
          >
            {/* Envelope Flap Lines */}
            <div className="absolute top-0 inset-x-0 h-1/2 border-b border-amber-500/20 pointer-events-none" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-400/10 via-transparent to-black/20 pointer-events-none rounded-2xl" />

            {/* Top Holly Decoration */}
            <div className="flex items-center gap-2 text-amber-300/80 text-xs font-serif-title tracking-wider mt-2">
              <span>✦</span>
              <span>NORTH POLE EXPRESS MAIL</span>
              <span>✦</span>
            </div>

            {/* Envelope Center Title */}
            <div className="text-center my-auto">
              <h2 className="text-3xl sm:text-5xl font-serif-title font-bold text-amber-100 tracking-tight drop-shadow-md">
                {envelopeTitle || 'Merry Christmas'}
              </h2>
              <p className="text-xs sm:text-sm text-amber-200/80 font-light mt-1">
                For the one who holds my heart
              </p>
            </div>

            {/* The Wax Seal in the center of the envelope */}
            <div className="relative flex flex-col items-center -mb-2">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-br from-red-800 to-rose-950 border-3 border-amber-500/80 shadow-2xl flex items-center justify-center group-hover:scale-110 group-hover:border-amber-300 transition-all duration-300 relative">
                {/* Snowflake or Monogram Emboss */}
                <span className="text-2xl sm:text-3xl text-amber-300 drop-shadow">❄️</span>
                <div className="absolute inset-0 rounded-full bg-amber-400/20 animate-pulse pointer-events-none" />
              </div>
              <span className="text-[11px] font-semibold text-amber-300 mt-2 tracking-wide uppercase group-hover:text-amber-200">
                Click to break seal & open
              </span>
            </div>
          </div>
        ) : (
          /* Opened Letter / Stationery View */
          <div className="relative w-full bg-[#fdfbf7] text-slate-900 rounded-2xl shadow-2xl border-4 border-[#e2d5c3] p-6 sm:p-10 flex flex-col max-h-[70vh] overflow-y-auto animate-scale-up">
            {/* Top Toolbar on letter */}
            <div className="flex items-center justify-between pb-3 border-b border-amber-900/10 mb-4">
              <div className="flex items-center gap-1.5 text-xs text-amber-900/70 font-serif-title">
                <span>🎄</span>
                <span>Christmas Keepsake</span>
              </div>
              <div className="flex items-center gap-2">
                {!isEditing ? (
                  <button
                    onClick={handleStartEdit}
                    className="flex items-center gap-1 px-3 py-1 text-xs font-medium text-amber-900 hover:text-amber-950 bg-amber-100 hover:bg-amber-200 rounded-md transition-colors cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit Letter</span>
                  </button>
                ) : (
                  <button
                    onClick={handleSave}
                    className="flex items-center gap-1 px-3 py-1 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-600 rounded-md transition-colors cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Save Changes</span>
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
                  title="Reseal Envelope"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Letter Content */}
            {!isEditing ? (
              <div className="flex flex-col text-left space-y-4 font-letter text-2xl sm:text-3xl text-slate-800 leading-relaxed">
                {/* Greeting */}
                <h3 className="font-serif-title text-xl sm:text-2xl text-red-900 font-bold mb-2">
                  {greeting}
                </h3>

                {/* Body Paragraphs */}
                <div className="whitespace-pre-line text-slate-800">
                  {body}
                </div>

                {/* Sign-off */}
                <div className="pt-4 text-right">
                  <p className="text-xl sm:text-2xl text-red-950 font-semibold font-serif-title">
                    {signoff}
                  </p>
                </div>
              </div>
            ) : (
              /* Inline Editing Form */
              <div className="flex flex-col gap-3 text-left">
                <div>
                  <label className="text-xs font-semibold text-amber-900 uppercase tracking-wide">
                    Greeting
                  </label>
                  <input
                    type="text"
                    value={greetingDraft}
                    onChange={(e) => setGreetingDraft(e.target.value)}
                    className="w-full px-3 py-1.5 mt-1 bg-white border border-amber-300 rounded text-base font-serif-title focus:outline-none focus:border-red-600"
                    placeholder="My Dearest Love,"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-amber-900 uppercase tracking-wide">
                    Letter Message
                  </label>
                  <textarea
                    rows={8}
                    value={bodyDraft}
                    onChange={(e) => setBodyDraft(e.target.value)}
                    className="w-full px-3 py-2 mt-1 bg-white border border-amber-300 rounded text-base font-letter leading-relaxed focus:outline-none focus:border-red-600"
                    placeholder="Write your heart out..."
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-amber-900 uppercase tracking-wide">
                    Sign-off
                  </label>
                  <input
                    type="text"
                    value={signoffDraft}
                    onChange={(e) => setSignoffDraft(e.target.value)}
                    className="w-full px-3 py-1.5 mt-1 bg-white border border-amber-300 rounded text-sm focus:outline-none focus:border-red-600"
                    placeholder="With all my love, always and forever ♡"
                  />
                </div>

                <div className="flex justify-end gap-2 mt-2">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-1.5 text-xs text-slate-600 hover:text-slate-900"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    className="px-5 py-1.5 text-xs font-semibold text-white bg-red-700 hover:bg-red-600 rounded-md"
                  >
                    Save Personalization
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Button to Move to Last "I Love You" Slide */}
      <div className="relative z-20 flex flex-col items-center mt-6">
        <button
          onClick={onNextSlide}
          className="group flex items-center gap-2 px-8 py-3.5 rounded-full bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-500 text-white font-semibold text-sm sm:text-base shadow-xl shadow-red-950/80 border border-amber-400/40 transition-all hover:scale-105 cursor-pointer"
        >
          <span>One Last Christmas Surprise for You</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
        <span className="text-[11px] text-amber-300/60 mt-1 font-light">
          Chapter 4 · The "I Love You" Slide ❤️
        </span>
      </div>
    </div>
  );
};
