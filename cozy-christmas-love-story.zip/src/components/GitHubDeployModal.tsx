import React, { useState } from 'react';
import { X, Github, Copy, Check, ExternalLink, Terminal, Globe } from 'lucide-react';

interface GitHubDeployModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GitHubDeployModal: React.FC<GitHubDeployModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const steps = [
    {
      title: '1. Create a New Repository on GitHub',
      detail: 'Go to github.com/new and create a new public or private repository named something sweet, like "christmas-gift" or "cozy-christmas". Do NOT check "Initialize with README".',
      command: '',
    },
    {
      title: '2. Push Your Code to GitHub',
      detail: 'In your terminal (or command prompt in this project folder), run these commands to push the project:',
      command: `git init\ngit add .\ngit commit -m "A Cozy Christmas Gift"\ngit branch -M main\ngit remote add origin https://github.com/<YOUR-USERNAME>/<YOUR-REPO-NAME>.git\ngit push -u origin main`,
    },
    {
      title: '3. Enable Free GitHub Pages Hosting',
      detail: 'In your GitHub repository, click "Settings" → "Pages" (left sidebar). Under "Build and deployment", choose "GitHub Actions" and select the standard "Static HTML / Vite" workflow, OR run "npm run build" and deploy the "dist" folder with the gh-pages tool.',
      command: `npm run build\nnpx gh-pages -d dist`,
    },
    {
      title: '4. Send the Link to Your Boyfriend!',
      detail: 'Your site will be live at https://<YOUR-USERNAME>.github.io/<YOUR-REPO-NAME>/. We already configured "base: ./" in vite.config.ts so everything loads seamlessly!',
      command: '',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 rounded-lg text-white">
              <Github className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-serif-title font-bold text-white">
                How to Deploy to GitHub & GitHub Pages
              </h3>
              <p className="text-xs text-slate-400">
                Step-by-step instructions to get your Christmas website live for your boyfriend.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-left text-xs sm:text-sm text-slate-300">
          {/* Important note */}
          <div className="bg-amber-950/40 border border-amber-500/30 rounded-xl p-3.5 flex items-start gap-2.5 text-amber-200">
            <span className="text-base">💡</span>
            <div>
              <span className="font-semibold block text-amber-100">Relative Base Path Ready:</span>
              <span>
                We already set <code className="bg-black/40 px-1.5 py-0.5 rounded text-amber-300">base: './'</code> in <code className="text-amber-300">vite.config.ts</code> so all images, audio, and styles work without path errors on GitHub Pages.
              </span>
            </div>
          </div>

          {/* Steps */}
          <div className="space-y-5">
            {steps.map((step, idx) => (
              <div key={idx} className="space-y-2">
                <h4 className="font-semibold text-white flex items-center gap-2">
                  <span className="text-amber-400">{step.title}</span>
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">{step.detail}</p>
                {step.command && (
                  <div className="relative group">
                    <pre className="p-3 bg-slate-950 border border-white/10 rounded-lg text-emerald-400 font-mono text-xs overflow-x-auto whitespace-pre">
                      {step.command}
                    </pre>
                    <button
                      onClick={() => copyToClipboard(step.command, idx)}
                      className="absolute top-2 right-2 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs flex items-center gap-1 border border-white/10 transition-colors cursor-pointer"
                    >
                      {copiedIndex === idx ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Tip on photos */}
          <div className="bg-slate-950/60 border border-white/10 rounded-xl p-3.5 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-slate-200">
              <Globe className="w-4 h-4 text-sky-400" />
              <span>Personalization Tip:</span>
            </div>
            <p className="text-xs text-slate-400">
              When you upload custom photos via the "Edit Gift" button, they are stored locally in your browser. To have them preloaded for anyone who opens the link, you can also place your couple photos in <code className="text-slate-200">src/assets/images/</code> and update <code className="text-slate-200">src/utils/defaultData.ts</code>, or use the "Export Backup" button in Edit Gift!
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-3.5 bg-slate-950 border-t border-white/10">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
          >
            Got it, thanks!
          </button>
        </div>
      </div>
    </div>
  );
};
