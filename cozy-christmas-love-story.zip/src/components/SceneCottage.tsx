import React, { useState } from 'react';
import { Sparkles, DoorOpen, Play, Snowflake, Heart } from 'lucide-react';
import { COTTAGE_IMAGE } from '../utils/defaultData';
import { audioEngine } from '../utils/audioEngine';

interface SceneCottageProps {
  questionText: string;
  buttonText: string;
  recipientName: string;
  onEnterCottage: () => void;
  onOpenSnowballGame: () => void;
}

export const SceneCottage: React.FC<SceneCottageProps> = ({
  questionText,
  buttonText,
  recipientName,
  onEnterCottage,
  onOpenSnowballGame,
}) => {
  const [isApproaching, setIsApproaching] = useState<boolean>(false);
  const [doorOpening, setDoorOpening] = useState<boolean>(false);

  const handleOpenDoor = () => {
    setDoorOpening(true);
    audioEngine.playDoorOpenSound();
    setTimeout(() => {
      onEnterCottage();
    }, 1100);
  };

  const handleApproach = () => {
    setIsApproaching(true);
    audioEngine.playSnowflakeSparkle();
  };

  return (
    <div className="relative w-full min-h-[calc(100vh-64px)] flex items-center justify-center overflow-hidden py-12 px-4 sm:px-6">
      {/* Background Image Container with Cinematic Zoom */}
      <div
        className={`absolute inset-0 bg-cover bg-center transition-transform duration-1000 ease-out ${
          isApproaching ? 'scale-125 translate-y-4' : 'scale-100'
        }`}
        style={{
          backgroundImage: `url(${COTTAGE_IMAGE})`,
        }}
      >
        {/* Soft atmospheric overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-slate-950/60" />
      </div>

      {/* Door Opening Golden Flash Transition */}
      <div
        className={`fixed inset-0 z-40 bg-amber-100 transition-opacity duration-1000 pointer-events-none ${
          doorOpening ? 'opacity-95' : 'opacity-0'
        }`}
      />

      {/* Interactive Porch Content */}
      <div className="relative z-30 max-w-xl w-full text-center flex flex-col items-center">
        {/* Decorative Holiday Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/80 border border-amber-400/30 text-amber-200 text-xs font-medium backdrop-blur-md shadow-lg mb-6">
          <span className="text-red-400 animate-pulse">❄️</span>
          <span>A Special Christmas Surprise for {recipientName || 'You'}</span>
          <span className="text-amber-400">✨</span>
        </div>

        {/* Main Title */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-serif-title font-bold text-white drop-shadow-lg tracking-tight mb-4">
          A Warm Haven in the Snow
        </h1>

        <p className="text-base sm:text-lg text-slate-200/90 font-light max-w-md mx-auto leading-relaxed drop-shadow mb-8">
          The snow is falling softly through the pines, and the cottage windows are glowing with warm amber light.
        </p>

        {/* Dynamic Interactive Card */}
        {!isApproaching ? (
          <div className="flex flex-col sm:flex-row items-center gap-4 bg-slate-950/70 border border-white/15 backdrop-blur-md p-6 rounded-2xl shadow-2xl max-w-md w-full animate-fade-in">
            <div className="flex-1 text-left">
              <h3 className="text-sm font-semibold text-amber-200">Arrived at the cottage gate</h3>
              <p className="text-xs text-slate-300 mt-0.5">Walk up the lantern-lit cobblestone path</p>
            </div>
            <div className="flex flex-col w-full sm:w-auto gap-2">
              <button
                onClick={handleApproach}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-semibold text-sm shadow-lg shadow-amber-500/20 transition-all hover:scale-105 cursor-pointer whitespace-nowrap"
              >
                Walk to the Door →
              </button>
              <button
                onClick={onOpenSnowballGame}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-medium border border-white/15 transition-all cursor-pointer whitespace-nowrap flex items-center justify-center gap-1.5"
              >
                <span>❄️ Snowball Fight in Yard</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-slate-950/85 border border-amber-500/40 backdrop-blur-lg p-6 sm:p-8 rounded-3xl shadow-2xl max-w-lg w-full flex flex-col items-center animate-fade-in">
            {/* Wreath Icon */}
            <div className="w-16 h-16 rounded-full bg-emerald-950/80 border-2 border-amber-400/50 flex items-center justify-center text-3xl shadow-inner mb-4 animate-sway">
              🎀
            </div>

            <h2 className="text-xl sm:text-2xl font-serif-title font-semibold text-amber-100 mb-2">
              {questionText || 'Would you like to go inside?'}
            </h2>

            <p className="text-xs sm:text-sm text-slate-300 font-light mb-6 text-center max-w-sm">
              The fire is already crackling, the mantle is decorated with our memories, and it's warm inside.
            </p>

            <div className="flex flex-col w-full gap-3">
              <button
                onClick={handleOpenDoor}
                disabled={doorOpening}
                className={`w-full py-3.5 px-6 rounded-xl font-semibold text-sm sm:text-base transition-all duration-300 flex items-center justify-center gap-2 shadow-xl cursor-pointer ${
                  doorOpening
                    ? 'bg-amber-400 text-slate-950 scale-98'
                    : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-500 text-white shadow-red-900/40 hover:scale-102'
                }`}
              >
                <DoorOpen className="w-5 h-5 text-amber-200" />
                <span>{doorOpening ? 'Opening Door...' : buttonText || 'Open the Door & Step Inside'}</span>
              </button>

              <div className="flex items-center justify-center gap-4 mt-2">
                <button
                  onClick={onOpenSnowballGame}
                  className="text-xs text-amber-300/80 hover:text-amber-200 underline decoration-amber-400/40 hover:decoration-amber-300 transition-colors cursor-pointer flex items-center gap-1"
                >
                  <span>❄️ Play a quick snowball fight first</span>
                </button>
                <span className="text-white/20">·</span>
                <button
                  onClick={() => setIsApproaching(false)}
                  className="text-xs text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                >
                  Step back to gate
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Floating Sparkle Hint */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-center pointer-events-none">
        <p className="text-[11px] text-slate-400 font-light tracking-wide bg-slate-950/50 backdrop-blur-sm px-3 py-1 rounded-full border border-white/5">
          Tap anywhere in the sky for Christmas sparkles ✨
        </p>
      </div>
    </div>
  );
};
