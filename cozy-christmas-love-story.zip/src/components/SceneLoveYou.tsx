import React, { useState } from 'react';
import { Heart, Sparkles, RotateCcw, Share2, Check, Plus, Trash2 } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';

interface SceneLoveYouProps {
  recipientName: string;
  senderName: string;
  headline: string;
  subtext: string;
  reasonsWhy: string[];
  onRestart: () => void;
  onOpenEditModal: () => void;
  onOpenGithubModal: () => void;
}

interface HeartParticle {
  id: number;
  x: number;
  y: number;
  size: number;
  speedY: number;
  rotation: number;
}

export const SceneLoveYou: React.FC<SceneLoveYouProps> = ({
  recipientName,
  senderName,
  headline,
  subtext,
  reasonsWhy,
  onRestart,
  onOpenEditModal,
  onOpenGithubModal,
}) => {
  const [openedReasons, setOpenedReasons] = useState<number[]>([0]);
  const [floatingHearts, setFloatingHearts] = useState<HeartParticle[]>([]);
  const [copied, setCopied] = useState<boolean>(false);

  const toggleReason = (idx: number) => {
    audioEngine.playHeartSound();
    setOpenedReasons((prev) =>
      prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
    );
  };

  const spawnHearts = () => {
    audioEngine.playHeartSound();
    const newHearts: HeartParticle[] = Array.from({ length: 18 }, () => ({
      id: Date.now() + Math.random(),
      x: Math.random() * window.innerWidth * 0.8 + window.innerWidth * 0.1,
      y: window.innerHeight - 80,
      size: Math.random() * 20 + 16,
      speedY: Math.random() * 3 + 2,
      rotation: Math.random() * 40 - 20,
    }));
    setFloatingHearts((prev) => [...prev, ...newHearts]);

    setTimeout(() => {
      setFloatingHearts((prev) => prev.slice(newHearts.length));
    }, 2800);
  };

  const handleCopyLink = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="relative w-full min-h-[calc(100vh-64px)] flex flex-col items-center justify-between py-10 px-4 sm:px-6 bg-[#0c1017] overflow-hidden">
      {/* Warm Ambient Glow */}
      <div className="absolute inset-0 bg-radial from-rose-950/30 via-slate-950 to-slate-950 pointer-events-none" />

      {/* Floating Hearts in Foreground */}
      {floatingHearts.map((h) => (
        <div
          key={h.id}
          className="fixed pointer-events-none z-50 text-rose-400 drop-shadow-lg transition-transform duration-1000 animate-fade-out"
          style={{
            left: h.x,
            bottom: h.y,
            fontSize: `${h.size}px`,
            transform: `translateY(-${h.speedY * 60}px) rotate(${h.rotation}deg)`,
          }}
        >
          ❤️
        </div>
      ))}

      {/* Top Tag */}
      <div className="relative z-20 text-center">
        <span className="text-xs uppercase tracking-widest text-rose-300 font-medium bg-rose-950/50 backdrop-blur-sm px-4 py-1.5 rounded-full border border-rose-500/30">
          Chapter 4 · With All My Heart
        </span>
      </div>

      {/* Central Hero Banner */}
      <div className="relative z-20 max-w-3xl w-full text-center flex flex-col items-center my-auto px-4 py-6">
        {/* Mistletoe & Heart Icon */}
        <div className="relative mb-4 flex items-center justify-center">
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-rose-600 to-red-600 border-4 border-amber-300/80 shadow-2xl shadow-rose-900/60 flex items-center justify-center text-4xl animate-bounce">
            ❤️
          </div>
          <div className="absolute -top-3 -right-2 text-2xl animate-sway">
            🌿
          </div>
        </div>

        {/* Big Romantic Headline */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-serif-title font-bold text-white tracking-tight leading-tight drop-shadow-md">
          {headline || `I Love You, ${recipientName || 'Forever and Always'}`}
        </h1>

        <p className="text-base sm:text-lg text-rose-200/90 font-light mt-3 max-w-xl mx-auto leading-relaxed">
          {subtext ||
            'More than all the snowflakes falling in the winter sky, more than hot cocoa on chilly mornings, and more than words could ever say.'}
        </p>

        {/* Sender Sign-off */}
        <div className="mt-2 text-amber-300 font-letter text-2xl sm:text-3xl">
          — {senderName || 'Forever Yours'} ♡
        </div>

        {/* "Little Reasons Why I Love You" Interactive Gift Tags Grid */}
        <div className="w-full mt-8 flex flex-col items-center">
          <div className="flex items-center gap-2 mb-4 text-xs font-semibold text-amber-300/90 uppercase tracking-wider">
            <span>🎁</span>
            <span>Little Reasons Why You Make Life Magical (Tap to open)</span>
            <span>✨</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 w-full">
            {reasonsWhy.map((reason, idx) => {
              const isOpened = openedReasons.includes(idx);
              return (
                <div
                  key={idx}
                  onClick={() => toggleReason(idx)}
                  className={`p-4 rounded-xl border transition-all duration-300 cursor-pointer flex flex-col justify-between text-left group ${
                    isOpened
                      ? 'bg-gradient-to-br from-rose-950/80 to-slate-900/90 border-rose-500/50 shadow-lg shadow-rose-950/50 scale-102'
                      : 'bg-slate-900/60 hover:bg-slate-900/90 border-white/10 hover:border-amber-400/30'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-amber-400">
                      Tag #{idx + 1}
                    </span>
                    <span className="text-sm group-hover:scale-125 transition-transform">
                      {isOpened ? '💌' : '🎁'}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-200 font-serif-title leading-relaxed">
                    {reason}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Interactive Burst Button */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={spawnHearts}
            className="flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-500 text-white font-semibold text-sm shadow-xl shadow-rose-900/50 border border-rose-400/40 transition-all hover:scale-105 cursor-pointer"
          >
            <Heart className="w-4 h-4 fill-white" />
            <span>Send Christmas Love Sparks ❤️</span>
          </button>
        </div>
      </div>

      {/* Footer Actions: Replay & Share */}
      <div className="relative z-20 w-full max-w-xl flex flex-col sm:flex-row items-center justify-between gap-3 pt-6 border-t border-white/10 mt-6">
        <button
          onClick={onRestart}
          className="flex items-center gap-2 px-4 py-2 text-xs font-medium text-amber-200 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Experience from Beginning</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyLink}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copied ? 'Link Copied!' : 'Copy Gift Link'}</span>
          </button>

          <button
            onClick={onOpenGithubModal}
            className="px-4 py-2 text-xs font-medium text-amber-300 bg-amber-950/50 hover:bg-amber-900/70 border border-amber-500/30 rounded-lg transition-colors cursor-pointer"
          >
            Deploy to GitHub
          </button>
        </div>
      </div>
    </div>
  );
};
