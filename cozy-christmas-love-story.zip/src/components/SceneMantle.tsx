import React, { useState } from 'react';
import { PhotoItem } from '../types';
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Upload, Edit3, ArrowDown, Sparkles } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';

interface SceneMantleProps {
  photos: PhotoItem[];
  onUpdatePhoto: (updated: PhotoItem) => void;
  onOpenFireplace: () => void;
}

export const SceneMantle: React.FC<SceneMantleProps> = ({
  photos,
  onUpdatePhoto,
  onOpenFireplace,
}) => {
  const [zoomedIndex, setZoomedIndex] = useState<number | null>(0);
  const [isEditingCaption, setIsEditingCaption] = useState<boolean>(false);
  const [captionDraft, setCaptionDraft] = useState<string>('');
  const [locationDraft, setLocationDraft] = useState<string>('');

  const activePhoto = zoomedIndex !== null ? photos[zoomedIndex] : null;

  const handleSelectPhoto = (index: number) => {
    setZoomedIndex(index);
    setIsEditingCaption(false);
    audioEngine.playSnowflakeSparkle();
  };

  const handleNextPhoto = () => {
    if (zoomedIndex === null) return;
    const next = (zoomedIndex + 1) % photos.length;
    setZoomedIndex(next);
    setIsEditingCaption(false);
    audioEngine.playSnowflakeSparkle();
  };

  const handlePrevPhoto = () => {
    if (zoomedIndex === null) return;
    const prev = (zoomedIndex - 1 + photos.length) % photos.length;
    setZoomedIndex(prev);
    setIsEditingCaption(false);
    audioEngine.playSnowflakeSparkle();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, photoId: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      const existing = photos.find((p) => p.id === photoId);
      if (existing) {
        onUpdatePhoto({
          ...existing,
          url: dataUrl,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveCaption = () => {
    if (!activePhoto) return;
    onUpdatePhoto({
      ...activePhoto,
      caption: captionDraft,
      location: locationDraft,
    });
    setIsEditingCaption(false);
  };

  const startEditing = () => {
    if (!activePhoto) return;
    setCaptionDraft(activePhoto.caption);
    setLocationDraft(activePhoto.location || '');
    setIsEditingCaption(true);
  };

  return (
    <div className="relative w-full min-h-[calc(100vh-64px)] flex flex-col items-center justify-between py-8 px-4 sm:px-6 bg-slate-950 overflow-hidden">
      {/* Warm Ambient Wall & Wallpaper Lighting */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#1b120c] via-[#241711] to-[#120a07] pointer-events-none" />
      <div className="absolute top-0 inset-x-0 h-48 bg-radial from-amber-600/20 via-transparent to-transparent pointer-events-none" />

      {/* Pine Garland & Fairy Lights across the top */}
      <div className="relative z-20 w-full max-w-5xl flex flex-col items-center mb-6">
        {/* Fairy lights string */}
        <div className="w-full flex justify-around items-center py-2 opacity-90">
          {Array.from({ length: 14 }).map((_, i) => (
            <div
              key={i}
              className={`w-3 h-3 rounded-full shadow-lg ${
                i % 3 === 0
                  ? 'bg-amber-300 shadow-amber-400/80 animate-pulse'
                  : i % 3 === 1
                  ? 'bg-red-500 shadow-red-500/80'
                  : 'bg-emerald-400 shadow-emerald-400/80 animate-pulse'
              }`}
              style={{ animationDuration: `${1.5 + (i % 4) * 0.5}s` }}
            />
          ))}
        </div>

        {/* Header Title */}
        <div className="text-center mt-2">
          <span className="text-xs uppercase tracking-widest text-amber-400/80 font-medium">
            Chapter 1 · The Mantle of Memories
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif-title font-bold text-amber-100 mt-1">
            Moments Resting Above the Hearth
          </h2>
          <p className="text-xs sm:text-sm text-amber-200/70 max-w-md mx-auto mt-1">
            Click on any framed photo to zoom in, cherish the memory, or upload your own pictures.
          </p>
        </div>
      </div>

      {/* Mantle & Zoomed Photo Showcase */}
      <div className="relative z-20 w-full max-w-4xl flex-1 flex flex-col items-center justify-center my-4">
        {zoomedIndex !== null && activePhoto ? (
          /* Zoomed-in Photo Card */
          <div className="relative flex flex-col items-center w-full max-w-xl bg-gradient-to-b from-[#2a1d17] to-[#1a120e] border-2 border-amber-600/40 rounded-2xl p-4 sm:p-6 shadow-2xl backdrop-blur-md animate-scale-up">
            {/* Golden Frame Border */}
            <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden bg-slate-900 border-4 border-[#c59d5f] shadow-inner group">
              <img
                src={activePhoto.url}
                alt={activePhoto.caption}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-102"
              />

              {/* Top overlay controls */}
              <div className="absolute top-3 right-3 flex items-center gap-2">
                {/* Upload / Replace Photo button */}
                <label className="p-2 rounded-lg bg-slate-950/80 hover:bg-slate-900 text-amber-200 border border-amber-400/40 shadow-lg cursor-pointer transition-all hover:scale-105">
                  <Upload className="w-4 h-4" />
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleFileUpload(e, activePhoto.id)}
                  />
                </label>
                <button
                  onClick={() => setZoomedIndex(null)}
                  className="p-2 rounded-lg bg-slate-950/80 hover:bg-slate-900 text-slate-300 border border-white/20 shadow-lg cursor-pointer transition-all hover:scale-105"
                  title="View all on mantle"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
              </div>

              {/* Photo Index Tag */}
              <div className="absolute bottom-3 left-3 bg-slate-950/80 text-amber-200 text-xs px-2.5 py-1 rounded-md border border-amber-500/30 font-medium">
                Memory {zoomedIndex + 1} of {photos.length}
              </div>
            </div>

            {/* Caption & Memory Note */}
            <div className="w-full mt-4 flex flex-col">
              {!isEditingCaption ? (
                <div className="flex items-start justify-between gap-3">
                  <div className="text-left flex-1">
                    <p className="text-base sm:text-lg font-serif-title text-amber-100 font-medium leading-relaxed">
                      "{activePhoto.caption}"
                    </p>
                    {activePhoto.location && (
                      <p className="text-xs text-amber-300/80 mt-1 flex items-center gap-1 font-light">
                        <span>📍 {activePhoto.location}</span>
                        {activePhoto.date && <span>· {activePhoto.date}</span>}
                      </p>
                    )}
                  </div>
                  <button
                    onClick={startEditing}
                    className="p-1.5 text-amber-400/80 hover:text-amber-200 bg-amber-950/40 border border-amber-500/20 rounded-md transition-colors cursor-pointer shrink-0"
                    title="Edit Caption"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="w-full flex flex-col gap-2 bg-slate-950/60 p-3 rounded-lg border border-amber-500/30">
                  <label className="text-[11px] font-medium text-amber-300 uppercase tracking-wider">
                    Edit Memory Caption
                  </label>
                  <input
                    type="text"
                    value={captionDraft}
                    onChange={(e) => setCaptionDraft(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 text-white rounded border border-amber-500/40 text-sm focus:outline-none focus:border-amber-400"
                    placeholder="Enter what you felt that day..."
                  />
                  <input
                    type="text"
                    value={locationDraft}
                    onChange={(e) => setLocationDraft(e.target.value)}
                    className="w-full px-3 py-1 bg-slate-900 text-slate-300 rounded border border-amber-500/40 text-xs focus:outline-none focus:border-amber-400"
                    placeholder="Location / Date (optional)"
                  />
                  <div className="flex justify-end gap-2 mt-1">
                    <button
                      onClick={() => setIsEditingCaption(false)}
                      className="px-3 py-1 text-xs text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveCaption}
                      className="px-3 py-1 text-xs font-semibold bg-amber-600 hover:bg-amber-500 text-slate-950 rounded"
                    >
                      Save Memory
                    </button>
                  </div>
                </div>
              )}

              {/* Prev / Next Controls */}
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-amber-800/30">
                <button
                  onClick={handlePrevPhoto}
                  className="flex items-center gap-1 text-xs font-medium text-amber-300 hover:text-amber-100 transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Previous Picture</span>
                </button>
                <div className="flex gap-1.5">
                  {photos.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSelectPhoto(idx)}
                      className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                        idx === zoomedIndex ? 'bg-amber-400 scale-125' : 'bg-white/20 hover:bg-white/40'
                      }`}
                    />
                  ))}
                </div>
                <button
                  onClick={handleNextPhoto}
                  className="flex items-center gap-1 text-xs font-medium text-amber-300 hover:text-amber-100 transition-colors cursor-pointer"
                >
                  <span>Next Picture</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Mantle Shelf View */
          <div className="w-full flex flex-col items-center">
            {/* The Wooden Mantle Shelf Beam */}
            <div className="relative w-full max-w-3xl flex justify-center items-end gap-4 sm:gap-8 px-4 pb-4">
              {photos.map((photo, idx) => (
                <div
                  key={photo.id}
                  onClick={() => handleSelectPhoto(idx)}
                  className="group relative flex flex-col items-center cursor-pointer transition-all duration-300 hover:-translate-y-3"
                >
                  {/* Photo Frame */}
                  <div className="relative w-28 sm:w-44 aspect-[4/3] bg-slate-900 border-4 border-[#c59d5f] rounded-lg shadow-xl overflow-hidden group-hover:border-amber-300 transition-colors">
                    <img
                      src={photo.url}
                      alt={photo.caption}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-amber-500/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <ZoomIn className="w-6 h-6 text-white drop-shadow-lg" />
                    </div>
                  </div>
                  {/* Tiny label on shelf */}
                  <span className="text-[11px] text-amber-200/90 font-serif-title mt-2 opacity-80 group-hover:opacity-100 truncate max-w-[120px]">
                    {photo.caption}
                  </span>
                </div>
              ))}
            </div>

            {/* Thick Dark Oak Mantle Shelf */}
            <div className="w-full max-w-3xl h-6 bg-gradient-to-r from-[#2c180e] via-[#4a2e1d] to-[#2c180e] border-t-2 border-amber-600/40 rounded-sm shadow-2xl relative flex items-center justify-center">
              <div className="w-full h-1 bg-amber-400/20"></div>
            </div>
          </div>
        )}
      </div>

      {/* Down to Fireplace CTA */}
      <div className="relative z-30 flex flex-col items-center mt-4">
        <button
          onClick={onOpenFireplace}
          className="group flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-amber-700/80 to-red-800/80 hover:from-amber-600 hover:to-red-700 text-amber-100 font-semibold text-sm border border-amber-500/40 shadow-xl shadow-red-950/60 transition-all hover:scale-105 cursor-pointer"
        >
          <span>Look down at the warm fire below</span>
          <ArrowDown className="w-4 h-4 group-hover:translate-y-1 transition-transform" />
        </button>
        <span className="text-[11px] text-amber-300/60 mt-1 font-light">
          Warm crackling hearth & sweet memory
        </span>
      </div>
    </div>
  );
};
