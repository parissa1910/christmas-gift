import { GiftStoryConfig } from '../types';
import { DEFAULT_GIFT_CONFIG } from './defaultData';

const STORAGE_KEY = 'cozy_christmas_gift_data_v1';

export function loadGiftConfig(): GiftStoryConfig {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return DEFAULT_GIFT_CONFIG;
    const parsed = JSON.parse(saved);
    return {
      ...DEFAULT_GIFT_CONFIG,
      ...parsed,
      photos: parsed.photos && parsed.photos.length > 0 ? parsed.photos : DEFAULT_GIFT_CONFIG.photos,
    };
  } catch (e) {
    console.error('Failed to load gift config:', e);
    return DEFAULT_GIFT_CONFIG;
  }
}

export function saveGiftConfig(config: GiftStoryConfig): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save gift config:', e);
  }
}

export function resetGiftConfig(): GiftStoryConfig {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.error('Failed to reset gift config:', e);
  }
  return DEFAULT_GIFT_CONFIG;
}
