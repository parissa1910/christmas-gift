/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GiftStoryConfig, SceneId, PhotoItem } from './types';
import { loadGiftConfig, saveGiftConfig } from './utils/storage';
import { SnowCanvas } from './components/SnowCanvas';
import { TopNav } from './components/TopNav';
import { SceneCottage } from './components/SceneCottage';
import { SceneMantle } from './components/SceneMantle';
import { SceneFireplace } from './components/SceneFireplace';
import { SceneLetter } from './components/SceneLetter';
import { SceneLoveYou } from './components/SceneLoveYou';
import { SnowballGameModal } from './components/SnowballGameModal';
import { EditGiftModal } from './components/EditGiftModal';
import { GitHubDeployModal } from './components/GitHubDeployModal';

export default function App() {
  const [config, setConfig] = useState<GiftStoryConfig>(() => loadGiftConfig());
  const [currentScene, setCurrentScene] = useState<SceneId>('cottage');
  const [isSnowballOpen, setIsSnowballOpen] = useState<boolean>(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [isGithubModalOpen, setIsGithubModalOpen] = useState<boolean>(false);
  const [isCustomizing, setIsCustomizing] = useState<boolean>(false);

  // Sync state to localStorage whenever config changes
  useEffect(() => {
    saveGiftConfig(config);
  }, [config]);

  const handleUpdateConfig = (updated: GiftStoryConfig) => {
    setConfig(updated);
    saveGiftConfig(updated);
  };

  const handleUpdatePhoto = (updatedPhoto: PhotoItem) => {
    setConfig((prev) => ({
      ...prev,
      photos: prev.photos.map((p) => (p.id === updatedPhoto.id ? updatedPhoto : p)),
    }));
  };

  const handleUpdateFireplaceQuote = (quote: string, subtext: string) => {
    setConfig((prev) => ({
      ...prev,
      fireplaceQuote: quote,
      fireplaceSubtext: subtext,
    }));
  };

  const handleUpdateLetter = (greeting: string, body: string, signoff: string) => {
    setConfig((prev) => ({
      ...prev,
      letterGreeting: greeting,
      letterBody: body,
      letterSignoff: signoff,
    }));
  };

  return (
    <div className="min-h-screen bg-[#0c121e] text-slate-100 flex flex-col relative select-none">
      {/* Interactive Snowflake Particle Canvas */}
      <SnowCanvas interactive={!isSnowballOpen && !isEditModalOpen && !isGithubModalOpen} />

      {/* Top Navigation */}
      <TopNav
        currentScene={currentScene}
        onSelectScene={(scene) => setCurrentScene(scene)}
        onOpenEditModal={() => setIsEditModalOpen(true)}
        onOpenGithubModal={() => setIsGithubModalOpen(true)}
        isCustomizing={isCustomizing}
        onToggleCustomizing={() => setIsCustomizing(!isCustomizing)}
      />

      {/* Main Narrative Scene Viewport */}
      <main className="flex-1 flex flex-col pt-14">
        {currentScene === 'cottage' && (
          <SceneCottage
            questionText={config.cottageQuestion}
            buttonText={config.cottageButtonText}
            recipientName={config.recipientName}
            onEnterCottage={() => setCurrentScene('mantle')}
            onOpenSnowballGame={() => setIsSnowballOpen(true)}
          />
        )}

        {currentScene === 'mantle' && (
          <SceneMantle
            photos={config.photos}
            onUpdatePhoto={handleUpdatePhoto}
            onOpenFireplace={() => setCurrentScene('fireplace')}
          />
        )}

        {currentScene === 'fireplace' && (
          <SceneFireplace
            quote={config.fireplaceQuote}
            subtext={config.fireplaceSubtext}
            onUpdateQuote={handleUpdateFireplaceQuote}
            onOpenLetter={() => setCurrentScene('letter')}
          />
        )}

        {currentScene === 'letter' && (
          <SceneLetter
            envelopeTitle={config.letterEnvelopeTitle}
            greeting={config.letterGreeting}
            body={config.letterBody}
            signoff={config.letterSignoff}
            onUpdateLetter={handleUpdateLetter}
            onNextSlide={() => setCurrentScene('loveyou')}
          />
        )}

        {currentScene === 'loveyou' && (
          <SceneLoveYou
            recipientName={config.recipientName}
            senderName={config.senderName}
            headline={config.loveYouHeadline}
            subtext={config.loveYouSubtext}
            reasonsWhy={config.reasonsWhy}
            onRestart={() => setCurrentScene('cottage')}
            onOpenEditModal={() => setIsEditModalOpen(true)}
            onOpenGithubModal={() => setIsGithubModalOpen(true)}
          />
        )}
      </main>

      {/* Bottom Scene Quick Dots Indicator */}
      <footer className="fixed bottom-3 right-4 z-30 pointer-events-auto">
        <div className="flex items-center gap-2 bg-slate-950/70 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 shadow-lg text-[11px] text-slate-300">
          <span className="text-amber-400 font-medium">Chapter:</span>
          {(['cottage', 'mantle', 'fireplace', 'letter', 'loveyou'] as SceneId[]).map((sc, idx) => (
            <button
              key={sc}
              onClick={() => setCurrentScene(sc)}
              className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                currentScene === sc ? 'bg-amber-400 scale-125 shadow-sm shadow-amber-300' : 'bg-white/20 hover:bg-white/50'
              }`}
              title={`Go to chapter ${idx + 1}`}
            />
          ))}
        </div>
      </footer>

      {/* Snowball Fight Mini-Game Modal */}
      <SnowballGameModal
        isOpen={isSnowballOpen}
        onClose={() => setIsSnowballOpen(false)}
        onGoInside={() => setCurrentScene('mantle')}
      />

      {/* Personalization / Edit Gift Modal */}
      <EditGiftModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        config={config}
        onSave={handleUpdateConfig}
      />

      {/* GitHub Deployment Guide Modal */}
      <GitHubDeployModal
        isOpen={isGithubModalOpen}
        onClose={() => setIsGithubModalOpen(false)}
      />
    </div>
  );
}
